# 나는 엄마다 0.3.0 — 구현 검증

2026-09-14 · 가족 설치용 시험 APK · 클레이모피즘 화면 · 위젯·부탁·비서 알림 추가

## 0.3 추가 검증 범위

- release APK versionCode3 / versionName `0.3.0-companion` 생성, APK Signature Scheme v2 확인.
- 모모 홈 위젯과 `모모에게 부탁하기` 화면 추가. 부탁은 기존 Android Keystore 키로 암호화한 JSON으로 저장하고 완료·다시 챙기기·삭제를 지원한다.
- 비서 브리핑 3개 시간, 평일만, 10분 미루기, 실제 최근 알림·미완료 부탁만 표시, 시험 알림은 실제 기록을 만들지 않음.
- 비서 알람은 정확한 알람·전체화면 접근을 사용자가 직접 허용하고 스위치를 켠 경우에만 알람 채널과 full-screen intent를 사용한다. 잠금화면에서는 잠금 해제 전 상세·부탁 텍스트를 표시하지 않는다.
- 웹 상태는 로그인 성공으로 단정하지 않고 `웹 방문 저장 · 인증 미확인`으로 표시. 실제 개인자료 조회·세션 자동 갱신은 미구현.

**후속 실기기 결과:** 같은 날 S23 Android16에 설치해 가상 알림 수집·기록 유지·일시정지·개별 삭제·백그라운드 수신을 확인했다. e알리미 특정 공지의 PDF 원문을 PC로 가져와 텍스트 추출에도 성공했다. 아래는 최초 빌드 시점 기록이며 최신 실측 범위와 미완료 사항은 [S23 검증 결과](../device-tests/2026-09-13-results.md)에 정리했다. 새 공지 자동 발견·전체 계정 연동은 아직 미검증이다.

## 확인한 결과

| 검증 | 결과 | 증거 |
|---|---|---|
| Android debug APK 빌드 | 성공 | `:app:assembleDebug` |
| 자동 테스트 | **21개 통과, 실패 0** | `app/build/reports/tests/testDebugUnitTest/index.html` |
| 정적 검사 | 오류 0, 경고 23 | `app/build/reports/lint-results-debug.html` |
| APK 서명 | APK Signature Scheme v2 검증 성공 | apksigner verify, Android Debug 인증서 |
| 설치 대상 | min SDK33 / target36 | aapt2 manifest badging |
| 네트워크 경계 | 나이스 공식 OpenAPI에만 학교정보 요청. 알림 원문 서버 전송 없음 | 코드 allowlist·실기기 연결 검사 |
| 화면 렌더링 | 실제 Compose 5개 상태 PNG 생성·육안 검수 | `app/build/reports/screenshots/` |
| 코드 교차 검수 | 지적한 복원·저장·초기 수집·오류 복구 문제 수정 확인 | 아래 수정 목록 |

최종 전체 검증 명령: `scripts/build.ps1 -Tasks @(':app:assembleDebug', ':app:testDebugUnitTest', ':app:lintDebug')`.

Windows 제한 프로세스의 Guava 임시폴더 ACL 때문에 화면 테스트 런타임이 실패하여, 같은 로컬 테스트를 표준 프로세스 권한으로 재실행했다. 테스트 홈/임시 경로는 `app/build` 안으로 지정했다. 테스트를 생략하거나 실패를 통과로 처리하지 않았다.

## v0.2 S24+ 실기기 결과

- Galaxy S24+ SM-S926N / Android16에 0.2.0-connectors 설치·실행 성공.
- 실제 설치된 e알리미·하이클래스를 감지하고 앱/사이트 통합 연결 목록에 표시.
- 비개인 테스트 프로필(별칭·학교·학년)을 저장하고 나이스 공식 학교정보 연결 성공.
- 공식 학교 검색 응답에서 학교코드·교육청코드를 저장하고 향후30일 학사일정5건을 앱에 표시.
- API가 `Accept: application/json`에 HTTP500, `Accept: */*`에 HTTP200을 반환하는 서버 호환성 문제를 같은 요청으로 재현하고 수정.
- 나이스 부모 개인자료는 공식 위임 API 미확인과 약관 제한 때문에 계정·비밀번호 자동 보관을 구현하지 않음. 앱에서는 ‘공식 연동 준비 중’으로 표시.
- 중복 ‘연결 설정 계속’ 버튼을 제거하고 앱/사이트 스위치 자체가 연결을 시작하도록 변경.
- e알리미 앱 ON에서 권한 이유 팝업→Samsung 알림 접근→복귀→앱 로그인 안내→실제 e알리미 Activity 실행을 확인. 개인 화면 내용은 읽지 않음.
- e알리미 공식 로그인 페이지를 허용 도메인 WebView로 표시. 로그인 전 확인 버튼 비활성, 취소 시 연결 OFF 복원 확인.

상세: [S24+ v0.2 검증](../device-tests/2026-09-13-s24-v02-results.md).

## 자동 테스트 구성

- ConnectorCatalogTest 3개: HTTPS·나이스/e알리미 호스트 allowlist와 로그인 상태 오판 방지.
- ProbeRulesTest 3개: 수집 동의·설정·실제 권한·선택 앱 gate, 제외 대상, revision/14일 경계.
- ProbeExporterTest 6개: 이름·전화·이메일·긴번호 가림, JSON/CSV escaping, 수식 주입 방지, 직접 식별자 제외, 잘림 표시와 시각 보존.
- ProbeCaptureReadinessTest 3개: 초기 설정 복원 기다리기, 대기 중 정책 변경 시 폐기, 대기 시간 제한.
- ProbeScreensRenderTest 5개: 홈 설정 복구 CTA, 동의 전 시작 차단, 명시 앱 선택, 이름 필수 검증, 320×640dp/글꼴1.5배에서 공백·길이 검증과 CTA 스크롤 접근.

UI 테스트는 Android34 Robolectric native graphics에서 프로덕션 Composable을 직접 렌더링한다. Windows PixelCopy가 완료되지 않아 실제 Activity의 view tree를 Android Canvas에 그려 PNG를 만들었다. **HTML 복제 화면이 아니지만, 물리 휴대폰이나 에뮬레이터 캡처도 아니다.** 그림자·OS 키보드·권한 화면은 실제 기기에서 다시 확인해야 한다.

## 시각 검수

참고는 `design/reference.png`, 구현은 `app/build/reports/screenshots/home-setup.png`다. 첫 비교에서 약한 그림자와 폰트 의존 장식 아이콘을 수정했다. 최종 비교는 92/100, 기준90 이상. 이 점수는 모델의 디자인 검수 판단이며 사용자 만족도나 실측 접근성 점수가 아니다.

크림/세이지/살구 팔레트, 볼록한 카드, 둥근 버튼, 잎 마크·종 마스코트를 확인했다. 글꼴 확대 시 장식이 본문을 밀지 않도록 마스코트를 숨긴다. 모든 긴 화면은 스크롤하며, 캡처된 큰 글꼴 상태에서 입력창과 다음 버튼이 접근 가능하다.

## 수정한 주요 결함

- 권한 설정을 확인하거나 앱 선택을 편집한 것만으로 사용자가 멈춘 수집을 다시 켜던 경로 분리.
- 설정/저장 실패를 Boolean으로 반환하여 실패 후 다음 화면으로 이동하지 않도록 수정.
- Activity 재생성 때 화면 복원, 반출 자료는 ViewModel 메모리에서 회전까지 유지. 프로세스가 사라지면 재검토 안내.
- 파일 저장 중 중단/실패 시 새로 만든 문서 정리 시도. 제공자가 삭제를 지원하지 않으면 빈 파일이 남을 수 있음.
- 설정 복원 전 첫 알림을 버리지 않도록 짧게 대기하고 정책 epoch 재검사.
- 기록 조회 실패 시 관찰을 재구독하고, 실패 상태를 숨기지 않으며 수집을 중단.
- 전체 삭제 직전의 오래된 DB emission이 삭제된 원문을 다시 표시하지 않도록 잠금 안에서 재조회.
- 기기에서 제거된 앱은 복귀 시 선택 목록에서 제외하여 수집 준비 상태를 오표시하지 않도록 처리.

## 남은 경고와 미검증

Lint 경고22개는 빌드/라이브러리 새 버전 안내17개, Application context를 보관하는 singleton 감지2개, KTX 사용 제안3개다. repository들은 Activity/Service가 아니라 `applicationContext`를 보관한다. 선택한 버전 조합을 빌드·테스트했으며 이번 작업에서 최신 버전으로 일괄 교체하지 않았다.

PC 에뮬레이터는 가속 드라이버 문제로 실행 검증에 실패했지만, 연결된 Galaxy S23과 S24+ Android16에서 설치·OS 권한 왕복·앱 실행·나이스 공개 API를 직접 검증했다.

따라서 다음은 **미검증**이다.

- Android13~15 및 Samsung 외 제조사에서의 OS 권한 화면 왕복.
- Android Keystore/Room과 웹 로그인 세션의 물리 기기 재부팅 후 유지·만료 복구.
- e알리미·하이클래스의 실제 신규 푸시 정보 확보율과 로그인 후 개인 원문 자동 읽기.
- 5~10명/7~14일/300건 실험과 원본 공지 대비 정보 확보율.
- Google Play 내부 테스트 배포, 정식 서명, 운영 개인정보 고지 검토.

APK는 설치 가능한 개발 산출물이다. 위 미검증이 해소되기 전 G0 통과나 V0 제품 완성으로 선언하지 않는다. AI 요약·일정 등록·자동 리마인더는 아직 제공하지 않는다.
