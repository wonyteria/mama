package kr.mom.probe.connector

import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class NeisSchool(
    val officeCode: String,
    val schoolCode: String,
    val name: String,
    val address: String,
    val level: String,
)

data class NeisEvent(val date: String, val name: String, val description: String)

sealed interface NeisResult<out T> {
    data class Success<T>(val value: T) : NeisResult<T>
    data class Failure(val message: String) : NeisResult<Nothing>
}

class NeisPublicClient {
    suspend fun findExactSchool(name: String): NeisResult<NeisSchool> = withContext(Dispatchers.IO) {
        val clean = name.trim()
        if (clean.length !in 2..60) return@withContext NeisResult.Failure("학교명을 정확히 입력해주세요.")
        val query = URLEncoder.encode(clean, StandardCharsets.UTF_8)
        val response = when (val fetched = getJson("https://open.neis.go.kr/hub/schoolInfo?Type=json&pIndex=1&pSize=5&SCHUL_NM=$query")) {
            is NeisResult.Success -> fetched.value
            is NeisResult.Failure -> return@withContext fetched
        }
        val rows = response.rows("schoolInfo")
        val parts = response.optJSONArray("schoolInfo")
        val total = parts?.optJSONObject(0)?.optJSONArray("head")?.optJSONObject(0)?.optInt("list_total_count", rows.size) ?: rows.size
        if (total > rows.size) return@withContext NeisResult.Failure("검색 결과가 많아요. 학교 이름을 더 길게 입력해주세요.")
        val exact = rows.filter { it.optString("SCHUL_NM").replace(" ", "") == clean.replace(" ", "") }
        val candidates = if (exact.isNotEmpty()) exact else rows
        when {
            candidates.isEmpty() -> NeisResult.Failure("학교를 찾지 못했어요. 학교 이름이나 지역을 함께 적어주세요.")
            candidates.size > 1 -> NeisResult.Failure("비슷한 학교가 여러 곳이에요. 지역명과 학교 이름을 함께 적어주세요.")
            else -> candidates.single().let { row -> NeisResult.Success(NeisSchool(
                officeCode = row.optString("ATPT_OFCDC_SC_CODE"), schoolCode = row.optString("SD_SCHUL_CODE"),
                name = row.optString("SCHUL_NM"), address = row.optString("ORG_RDNMA"), level = row.optString("SCHUL_KND_SC_NM"),
            )) }
        }
    }

    suspend fun upcomingEvents(school: NeisSchool, from: LocalDate = LocalDate.now(), days: Long = 30): NeisResult<List<NeisEvent>> = withContext(Dispatchers.IO) {
        val formatter = DateTimeFormatter.BASIC_ISO_DATE
        val url = "https://open.neis.go.kr/hub/SchoolSchedule?Type=json&pIndex=1&pSize=5" +
            "&ATPT_OFCDC_SC_CODE=${school.officeCode}&SD_SCHUL_CODE=${school.schoolCode}" +
            "&AA_FROM_YMD=${from.format(formatter)}&AA_TO_YMD=${from.plusDays(days).format(formatter)}"
        val response = when (val fetched = getJson(url)) {
            is NeisResult.Success -> fetched.value
            is NeisResult.Failure -> return@withContext fetched
        }
        val result = response.resultCode()
        if (result == "INFO-200") return@withContext NeisResult.Success(emptyList())
        val events = response.rows("SchoolSchedule").map { row ->
            NeisEvent(row.optString("AA_YMD"), row.optString("EVENT_NM"), row.optString("EVENT_CNTNT"))
        }
        NeisResult.Success(events)
    }

    private fun getJson(rawUrl: String): NeisResult<JSONObject> {
        val uri = URI(rawUrl)
        if (uri.scheme != "https" || uri.host != "open.neis.go.kr") return NeisResult.Failure("허용되지 않은 학교정보 주소예요.")
        val connection = uri.toURL().openConnection() as HttpURLConnection
        return try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.instanceFollowRedirects = false
            // The official endpoint returns HTTP 500 for Accept: application/json even
            // when Type=json is present; */* is the observed compatible representation.
            connection.setRequestProperty("Accept", "*/*")
            connection.setRequestProperty("User-Agent", "MomAgentProbe/0.2")
            if (connection.responseCode != 200) return NeisResult.Failure("나이스 서버가 응답하지 않았어요. (${connection.responseCode})")
            val contentType = connection.contentType.orEmpty().lowercase()
            if (!contentType.contains("json")) return NeisResult.Failure("나이스 응답 형식을 확인하지 못했어요.")
            val bytes = connection.inputStream.use { it.readNBytes(512_001) }
            if (bytes.size > 512_000) return NeisResult.Failure("나이스 응답이 예상보다 커서 중단했어요.")
            NeisResult.Success(JSONObject(bytes.toString(Charsets.UTF_8)))
        } catch (error: Exception) {
            NeisResult.Failure("나이스 연결 오류: ${error.javaClass.simpleName}")
        } finally { connection.disconnect() }
    }
}

private fun JSONObject.rows(name: String): List<JSONObject> {
    val parts = optJSONArray(name) ?: return emptyList()
    for (index in 0 until parts.length()) {
        val rows = parts.optJSONObject(index)?.optJSONArray("row") ?: continue
        return (0 until rows.length()).mapNotNull { rows.optJSONObject(it) }
    }
    return emptyList()
}

private fun JSONObject.resultCode(): String? = optJSONObject("RESULT")?.optString("CODE")
