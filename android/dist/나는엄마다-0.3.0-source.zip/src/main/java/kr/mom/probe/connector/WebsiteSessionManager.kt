package kr.mom.probe.connector

import android.webkit.CookieManager
import android.webkit.WebStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object WebsiteSessionManager {
    // WebView shares its cookie jar across these sites. Reset the whole jar and
    // matching connection metadata together, instead of claiming per-path deletion.
    suspend fun clearAll(): Boolean = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { continuation ->
            val manager = CookieManager.getInstance()
            manager.removeAllCookies {
                manager.flush()
                WebStorage.getInstance().deleteAllData()
                if (continuation.isActive) continuation.resume(!manager.hasCookies())
            }
        }
    }
}
