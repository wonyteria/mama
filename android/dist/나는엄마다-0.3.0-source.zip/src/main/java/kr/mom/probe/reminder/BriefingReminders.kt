package kr.mom.probe.reminder

import android.app.*
import android.content.*
import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import kr.mom.probe.R
import kr.mom.probe.data.ProbeRepository
import kr.mom.probe.data.ProbeRules
import kr.mom.probe.task.AssistantTaskStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

data class BriefingTime(val enabled: Boolean, val hour: Int, val minute: Int, val weekdaysOnly: Boolean = false)

object BriefingReminders {
    private const val PREFS = "briefing-reminders"
    private const val CHANNEL = "mom-briefing"
    private const val ALARM_CHANNEL = "mom-assistant-alarm"
    const val DEMO = "demo"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun read(context: Context, slot: Int): BriefingTime = prefs(context).let {
        BriefingTime(it.getBoolean("enabled$slot", false), it.getInt("hour$slot", when (slot) { 0 -> 7; 1 -> 20; else -> 12 }), it.getInt("minute$slot", if (slot == 1) 30 else 0), it.getBoolean("weekdays$slot", false))
    }
    fun save(context: Context, slot: Int, value: BriefingTime): Boolean {
        require(slot in 0..2 && value.hour in 0..23 && value.minute in 0..59)
        val previous = read(context, slot)
        if (!prefs(context).edit().putBoolean("enabled$slot", value.enabled).putInt("hour$slot", value.hour).putInt("minute$slot", value.minute).putBoolean("weekdays$slot", value.weekdaysOnly).commit()) {
            prefs(context).edit().putBoolean("enabled$slot", previous.enabled).putInt("hour$slot", previous.hour).putInt("minute$slot", previous.minute).putBoolean("weekdays$slot", previous.weekdaysOnly).commit()
            return false
        }
        schedule(context, slot)
        context.getSystemService(AlarmManager::class.java).cancel(pending(context, slot, delayed = true))
        if (!value.enabled) context.getSystemService(NotificationManager::class.java).cancel(710 + slot)
        return true
    }
    private fun pending(context: Context, slot: Int, snooze: Boolean = false, delayed: Boolean = false) = PendingIntent.getBroadcast(context, (if (delayed) 810 else 710) + slot,
        Intent(context, BriefingReceiver::class.java).setAction(if (snooze) "SNOOZE" else if (delayed) "SNOOZED_FIRE" else "FIRE").putExtra("slot", slot).putExtra("generation", generation(context)), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun generation(context: Context): Long = prefs(context).getLong("generation", 0)
    fun alarmMode(context: Context): Boolean = prefs(context).getBoolean("alarmMode", false)
    fun alarmPermissions(context: Context): Boolean = context.getSystemService(AlarmManager::class.java).canScheduleExactAlarms() &&
        (Build.VERSION.SDK_INT < 34 || context.getSystemService(NotificationManager::class.java).canUseFullScreenIntent())
    fun saveAlarmMode(context: Context, enabled: Boolean): Boolean {
        if (enabled && !alarmPermissions(context)) return false
        val previous = alarmMode(context)
        if (!prefs(context).edit().putBoolean("alarmMode", enabled).commit()) {
            prefs(context).edit().putBoolean("alarmMode", previous).commit()
            return false
        }
        restore(context)
        return true
    }
    fun schedule(context: Context, slot: Int) {
        val manager = context.getSystemService(AlarmManager::class.java)
        val operation = pending(context, slot)
        manager.cancel(operation)
        val value = read(context, slot)
        if (value.enabled) at(context, BriefingSchedule.nextFire(System.currentTimeMillis(), value.hour, value.minute, weekdaysOnly = value.weekdaysOnly), operation)
    }
    private fun at(context: Context, time: Long, operation: PendingIntent) {
        val manager = context.getSystemService(AlarmManager::class.java)
        try {
            if (alarmMode(context) && alarmPermissions(context)) {
                val show = PendingIntent.getActivity(context, 900, Intent(context, BriefingSettingsActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                manager.setAlarmClock(AlarmManager.AlarmClockInfo(time, show), operation)
            } else if (manager.canScheduleExactAlarms()) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, operation)
            else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, operation)
        } catch (_: SecurityException) { manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, operation) }
    }
    fun restore(context: Context) { (0..2).forEach { schedule(context, it) } }
    @Synchronized fun reset(context: Context) {
        val nextGeneration = generation(context) + 1
        prefs(context).edit().clear().putLong("generation", nextGeneration).commit()
        val alarms = context.getSystemService(AlarmManager::class.java)
        (0..2).forEach { alarms.cancel(pending(context, it)); alarms.cancel(pending(context, it, delayed = true)); context.getSystemService(NotificationManager::class.java).cancel(710 + it) }
    }
    fun unseenCount(context: Context, repository: ProbeRepository): Int {
        if (!repository.settings.value.collectionEnabled) return 0
        val since = maxOf(prefs(context).getLong("seen", 0), System.currentTimeMillis() - 24 * 60 * 60 * 1000L)
        return repository.records.value.count { it.receivedAt > since && it.packageName in repository.settings.value.selectedPackages }
    }
    fun markSeen(context: Context, timestamp: Long) { prefs(context).edit().putLong("seen", timestamp).apply(); (0..2).forEach { context.getSystemService(NotificationManager::class.java).cancel(710 + it) } }
    fun eligible(repository: ProbeRepository): Boolean = repository.isReady.value && repository.settings.value.let {
        it.consent && it.consentVersion == ProbeRules.CONSENT_VERSION && it.onboardingDone && repository.lastError.value == null
    }
    @Synchronized fun notify(context: Context, slot: Int, count: Int, demo: Boolean = false, expectedGeneration: Long = generation(context), taskCount: Int = 0): Boolean {
        if (expectedGeneration != generation(context)) return false
        if (!demo && (!read(context, slot).enabled || !eligible(ProbeRepository.get(context)))) return false
        if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "비서 브리핑", NotificationManager.IMPORTANCE_HIGH).apply { description = "정한 시간에 새로 모인 알림을 안내해요"; enableVibration(true) })
        val ringing = alarmMode(context) && alarmPermissions(context)
        if (ringing) manager.createNotificationChannel(NotificationChannel(ALARM_CHANNEL, "비서 알람", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "직접 설정한 시간에 알람 소리로 비서를 불러요"
            enableVibration(true)
            setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        })
        val channel = if (ringing) ALARM_CHANNEL else CHANNEL
        if (!manager.areNotificationsEnabled() || manager.getNotificationChannel(channel).importance == NotificationManager.IMPORTANCE_NONE) return false
        val open = PendingIntent.getActivity(context, 710 + slot, Intent(context, BriefingActivity::class.java).putExtra(DEMO, demo).putExtra("ringing", ringing).putExtra("slot", slot), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val note = NotificationCompat.Builder(context, channel).setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle(if (demo) "비서 알림 미리보기" else "모모가 새 알림을 모아뒀어요")
            .setContentText(if (demo) "시험 알림이에요. 실제 기록은 만들지 않아요." else "부탁 ${taskCount}개 · 새 알림 ${count}개")
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setContentIntent(open).setAutoCancel(true)
            .setCategory(if (ringing) NotificationCompat.CATEGORY_ALARM else NotificationCompat.CATEGORY_REMINDER).setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, "브리핑 열기", open)
        if (ringing) note.setFullScreenIntent(open, true).setTimeoutAfter(30_000)
        if (!demo) note.addAction(0, "10분 뒤", pending(context, slot, true))
        return try { manager.notify(710 + slot, note.build()); true } catch (_: SecurityException) { false }
    }
    fun snooze(context: Context, slot: Int) {
        if (read(context, slot).enabled) at(context, System.currentTimeMillis() + 600_000, pending(context, slot, delayed = true))
        context.getSystemService(NotificationManager::class.java).cancel(710 + slot)
    }
}

class BriefingReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action in listOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED, AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED)) { BriefingReminders.restore(context); return }
        val slot = intent.getIntExtra("slot", 0)
        val generation = intent.getLongExtra("generation", -1)
        if (slot !in 0..2 || generation != BriefingReminders.generation(context) || !BriefingReminders.read(context, slot).enabled) return
        if (intent.action == "SNOOZE") { BriefingReminders.snooze(context, slot); return }
        if (intent.action == "FIRE") BriefingReminders.schedule(context, slot)
        val result = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
            try {
                withTimeout(7_000) {
                    val repository = ProbeRepository.get(context)
                    repository.isReady.first { it }
                    if (generation == BriefingReminders.generation(context) && BriefingReminders.eligible(repository) && BriefingReminders.read(context, slot).enabled) {
                        val count = BriefingReminders.unseenCount(context, repository)
                        val taskStore = AssistantTaskStore.get(context)
                        withContext(Dispatchers.IO) { taskStore.load() }
                        val taskCount = taskStore.tasks.value.count { !it.completed }
                        if (count > 0 || taskCount > 0) BriefingReminders.notify(context, slot, count, expectedGeneration = generation, taskCount = taskCount)
                    }
                }
            } catch (_: Exception) {
                // The next scheduled briefing retries once the repository is available.
            } finally { result.finish() }
        }
    }
}
