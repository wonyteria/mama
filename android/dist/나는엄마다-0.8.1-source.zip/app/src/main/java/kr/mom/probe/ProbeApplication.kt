package kr.mom.probe

import android.app.Application
import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit
import kr.mom.probe.data.ProbeRepository
import kr.mom.probe.connector.WebsiteHealthWorker

class ProbeApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val migrations = getSharedPreferences("mom-migrations", MODE_PRIVATE)
        if (!migrations.getBoolean("removed-candidate-feedback-v1", false)) {
            val removed = getSharedPreferences("candidate_feedback", MODE_PRIVATE).edit().clear().commit()
            if (removed) migrations.edit().putBoolean("removed-candidate-feedback-v1", true).commit()
        }
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "expire-probe-records", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<ExpiryWorker>(1, TimeUnit.DAYS).build()
        )
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "website-session-health", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<WebsiteHealthWorker>(12, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
        )
    }
}

class ExpiryWorker(context: Context, parameters: WorkerParameters) : CoroutineWorker(context, parameters) {
    override suspend fun doWork(): Result = try {
        if (ProbeRepository.get(applicationContext).cleanupExpired()) Result.success() else Result.retry()
    } catch (_: Exception) { Result.retry() }
}
