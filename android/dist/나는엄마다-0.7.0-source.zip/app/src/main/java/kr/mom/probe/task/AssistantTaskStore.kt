package kr.mom.probe.task

import android.content.Context
import android.util.Base64
import java.io.IOException
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kr.mom.probe.data.ProbeCrypto
import kr.mom.probe.data.ProbeRepository
import kr.mom.probe.data.ProbeRules
import org.json.JSONArray
import org.json.JSONObject

enum class AssistantTaskSource { USER_LOCAL, USER_CONFIRMED_NOTICE, AUTO_NOTICE, LEGACY }

data class AssistantTask(
    val id: String,
    val text: String,
    val completed: Boolean,
    val createdAt: Long,
    val sourceNotificationId: String? = null,
    val sourceRevisionId: String? = null,
    val sourceKind: AssistantTaskSource = AssistantTaskSource.USER_LOCAL,
    val dueAt: Long? = null,
    val remindAt: Long? = null,
    val reminderAttempts: Int = 0,
    val suspended: Boolean = false,
)

/** Entire payload is encrypted using the existing Android Keystore-backed local data key. */
class AssistantTaskStore private constructor(context: Context) {
    private val app = context.applicationContext
    private val preferences = app.getSharedPreferences("assistant_tasks", Context.MODE_PRIVATE)
    private val mutableTasks = MutableStateFlow<List<AssistantTask>>(emptyList())
    val tasks = mutableTasks.asStateFlow()
    private var loaded = false

    private fun requireConsent() {
        val repository = ProbeRepository.get(app)
        val settings = repository.settings.value
        check(repository.isReady.value && repository.lastError.value == null && settings.consent &&
            settings.consentVersion == ProbeRules.CONSENT_VERSION && settings.onboardingDone) {
            "앱에서 처음 설정을 마쳐주세요."
        }
    }

    @Synchronized
    fun load() {
        requireConsent()
        val encoded = preferences.getString("encrypted", null)
        val result = if (encoded == null) emptyList() else {
            val array = JSONArray(ProbeCrypto().decrypt(Base64.decode(encoded, Base64.NO_WRAP), "assistant_tasks"))
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                AssistantTask(
                    item.getString("id"),
                    item.getString("text"),
                    item.getBoolean("completed"),
                    item.getLong("createdAt"),
                    item.optString("sourceNotificationId").ifBlank { item.optString("sourceRecordId").ifBlank { null } },
                    item.optString("sourceRevisionId").ifBlank { null },
                    runCatching { AssistantTaskSource.valueOf(item.optString("sourceKind")) }
                        .getOrDefault(if (item.optString("sourceNotificationId").isNotBlank() || item.optString("sourceRecordId").isNotBlank()) AssistantTaskSource.LEGACY else AssistantTaskSource.USER_LOCAL),
                    item.optionalLong("dueAt"),
                    item.optionalLong("remindAt"),
                    item.optInt("reminderAttempts", 0).coerceIn(0, 2),
                    item.optBoolean("suspended", false),
                )
            }
        }
        mutableTasks.value = result
        loaded = true
        TaskReminderScheduler.sync(app, result)
    }

    @Synchronized
    fun add(text: String, sourceNotificationId: String? = null, dueAt: Long? = null, remindAt: Long? = null): Boolean {
        return addTask(text, sourceNotificationId, dueAt, remindAt) != null
    }

    @Synchronized
    fun addTask(
        text: String,
        sourceNotificationId: String? = null,
        dueAt: Long? = null,
        remindAt: Long? = null,
        sourceRevisionId: String? = null,
        sourceKind: AssistantTaskSource = if (sourceNotificationId == null) AssistantTaskSource.USER_LOCAL else AssistantTaskSource.USER_CONFIRMED_NOTICE,
    ): AssistantTask? {
        val normalized = text.trim()
        require(normalized.isNotEmpty() && normalized.length <= MAX_TEXT) { "부탁을 1~300자로 적어주세요." }
        require(dueAt == null || dueAt > 0L) { "기한을 다시 확인해주세요." }
        require(remindAt == null || remindAt > 0L) { "알림 시간을 다시 확인해주세요." }
        var current = mutableTasks.value
        if (sourceNotificationId != null) {
            val sameSource = current.filter { it.sourceNotificationId == sourceNotificationId }
            if (sameSource.any { it.sourceKind != AssistantTaskSource.AUTO_NOTICE || sourceKind != AssistantTaskSource.AUTO_NOTICE }) return null
            val existing = sameSource.firstOrNull { !it.completed } ?: sameSource.firstOrNull()
            if (existing != null) {
                if (existing.completed) {
                    val updated = current.map {
                        if (it.id == existing.id && sourceRevisionId != null) it.copy(sourceRevisionId = sourceRevisionId) else it
                    }
                    if (updated != current) save(updated)
                    return null
                }
                val updated = existing.copy(
                    text = normalized,
                    sourceRevisionId = sourceRevisionId ?: existing.sourceRevisionId,
                    dueAt = dueAt,
                    remindAt = remindAt,
                    reminderAttempts = 0,
                    suspended = false,
                )
                if (updated == existing) return null
                save(listOf(updated) + current.filterNot { it.id == existing.id })
                return updated
            }
        }
        check(current.size < MAX_TASKS) { "부탁이 200개 모였어요. 끝난 부탁을 삭제해주세요." }
        val task = AssistantTask(UUID.randomUUID().toString(), normalized, false, System.currentTimeMillis(), sourceNotificationId, sourceRevisionId, sourceKind, dueAt, remindAt, 0)
        save(listOf(task) + current)
        return task
    }

    @Synchronized
    fun setCompleted(id: String, completed: Boolean) {
        save(mutableTasks.value.map { if (it.id == id) it.copy(completed = completed) else it })
        if (completed) TaskReminderScheduler.cancel(app, id)
    }

    @Synchronized
    fun delete(id: String) {
        TaskReminderScheduler.cancel(app, id)
        save(mutableTasks.value.filterNot { it.id == id })
    }

    @Synchronized
    fun suspendAutomaticSource(sourceNotificationId: String, sourceRevisionId: String): Boolean {
        val next = reconcileAutomaticRevision(mutableTasks.value, sourceNotificationId, sourceRevisionId)
        if (next == mutableTasks.value) return false
        mutableTasks.value.filter { before ->
            before.sourceNotificationId == sourceNotificationId && before.sourceKind == AssistantTaskSource.AUTO_NOTICE &&
                next.firstOrNull { it.id == before.id }?.remindAt == null
        }.forEach { TaskReminderScheduler.cancel(app, it.id) }
        save(next)
        return true
    }

    /** Atomically makes an alarm one-shot before its private notification is posted. */
    @Synchronized
    internal fun consumeReminder(id: String): AssistantTask? {
        val (next, fired) = consumeReminderFrom(mutableTasks.value, id)
        if (fired != null) save(next)
        return fired
    }

    @Synchronized
    internal fun rescheduleReminder(id: String, remindAt: Long) {
        require(remindAt > System.currentTimeMillis())
        save(mutableTasks.value.map { if (it.id == id && !it.completed) it.copy(remindAt = remindAt, reminderAttempts = (it.reminderAttempts + 1).coerceAtMost(2)) else it })
    }

    private fun save(next: List<AssistantTask>) {
        requireConsent()
        check(loaded) { "저장된 부탁을 먼저 불러와주세요." }
        val array = JSONArray().apply { next.forEach { task -> put(JSONObject()
            .put("id", task.id).put("text", task.text).put("completed", task.completed).put("createdAt", task.createdAt)
            .put("sourceNotificationId", task.sourceNotificationId ?: JSONObject.NULL)
            .put("sourceRevisionId", task.sourceRevisionId ?: JSONObject.NULL).put("sourceKind", task.sourceKind.name)
            .put("dueAt", task.dueAt ?: JSONObject.NULL).put("remindAt", task.remindAt ?: JSONObject.NULL)
            .put("reminderAttempts", task.reminderAttempts).put("suspended", task.suspended)) } }
        val ciphertext = Base64.encodeToString(ProbeCrypto().encrypt(array.toString(), "assistant_tasks"), Base64.NO_WRAP)
        if (!preferences.edit().putString("encrypted", ciphertext).commit()) throw IOException("부탁을 저장하지 못했어요. 다시 시도해주세요.")
        mutableTasks.value = next
        TaskReminderScheduler.sync(app, next)
    }

    @Synchronized
    private fun clear() {
        // Close mutations before reset; callers must first close the main repository consent gate.
        loaded = false
        mutableTasks.value = emptyList()
        if (!preferences.edit().clear().commit()) throw IOException("부탁 기록을 삭제하지 못했어요.")
        TaskReminderScheduler.sync(app, emptyList())
    }

    companion object {
        const val MAX_TEXT = 300
        private const val MAX_TASKS = 200
        internal fun consumeReminderFrom(tasks: List<AssistantTask>, id: String): Pair<List<AssistantTask>, AssistantTask?> {
            val fired = tasks.firstOrNull { it.id == id && !it.completed && !it.suspended && it.remindAt != null } ?: return tasks to null
            return tasks.map { if (it.id == id) it.copy(remindAt = null) else it } to fired
        }
        @Volatile private var instance: AssistantTaskStore? = null
        fun get(context: Context): AssistantTaskStore = instance ?: synchronized(this) {
            instance ?: AssistantTaskStore(context).also { instance = it }
        }
        fun reset(context: Context) = get(context).clear()
        internal fun reconcileAutomaticRevisionForTest(
            tasks: List<AssistantTask>,
            sourceNotificationId: String,
            sourceRevisionId: String,
        ): List<AssistantTask> = reconcileAutomaticRevision(tasks, sourceNotificationId, sourceRevisionId)

        private fun reconcileAutomaticRevision(
            tasks: List<AssistantTask>,
            sourceNotificationId: String,
            sourceRevisionId: String,
        ): List<AssistantTask> = tasks.map {
            if (it.sourceNotificationId == sourceNotificationId && it.sourceKind == AssistantTaskSource.AUTO_NOTICE &&
                !it.completed && (it.sourceRevisionId == null || it.sourceRevisionId != sourceRevisionId || !it.suspended)
            ) it.copy(sourceRevisionId = sourceRevisionId, remindAt = null, reminderAttempts = 0, suspended = true) else it
        }
    }
}

private fun JSONObject.optionalLong(name: String): Long? =
    if (!has(name) || isNull(name)) null else optLong(name).takeIf { it > 0L }
