package kr.mom.probe.agent

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.io.IOException
import kr.mom.probe.BuildConfig
import kr.mom.probe.MainActivity
import kr.mom.probe.data.ProbeRepository
import kr.mom.probe.data.ProbeRules
import kr.mom.probe.task.AssistantTaskStore
import kr.mom.probe.task.AssistantTasksActivity
import kr.mom.probe.task.TaskReminderScheduler
import kr.mom.probe.task.AssistantTask
import kr.mom.probe.ui.AgentButton
import kr.mom.probe.ui.AgentCard
import kr.mom.probe.ui.BellMascot
import kr.mom.probe.ui.Clay
import kr.mom.probe.ui.ClayCard
import kr.mom.probe.ui.MomTheme
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AgentActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (!BuildConfig.DEBUG) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setContent { MomTheme { LocalAgent() } }
    }

    @Composable
    private fun LocalAgent() {
        val repository = remember { ProbeRepository.get(this) }
        val ready by repository.isReady.collectAsStateWithLifecycle()
        val settings by repository.settings.collectAsStateWithLifecycle()
        val records by repository.records.collectAsStateWithLifecycle()
        val repositoryError by repository.lastError.collectAsStateWithLifecycle()
        val allowed = ready && repositoryError == null && settings.consent && settings.onboardingDone &&
            settings.consentVersion == ProbeRules.CONSENT_VERSION
        val taskStore = remember { AssistantTaskStore.get(this) }
        val tasks by taskStore.tasks.collectAsStateWithLifecycle()
        val engine = remember { LocalAgentEngine() }
        val messages = remember { mutableStateListOf(
            ChatMessage(false, "안녕하세요. 모모예요. 준비물, 제출할 것, 마감을 물어보거나 챙길 일을 맡겨주세요."),
        ) }
        val scope = rememberCoroutineScope()
        val listState = rememberLazyListState()
        val keyboard = LocalSoftwareKeyboardController.current
        var draft by rememberSaveable { mutableStateOf("") }
        var loaded by remember { mutableStateOf(false) }
        var busy by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }
        var undoTask by remember { mutableStateOf<AssistantTask?>(null) }

        suspend fun storeOperation(action: () -> Unit): Boolean {
            busy = true
            return try {
                withContext(Dispatchers.IO) { action() }
                error = null
                true
            } catch (failure: Exception) {
                if (failure is CancellationException) throw failure
                error = if (failure is IllegalArgumentException || failure is IllegalStateException || failure is IOException) {
                    failure.message
                } else {
                    "부탁을 불러오거나 저장하지 못했어요. 다시 시도해주세요."
                }
                false
            } finally {
                busy = false
            }
        }

        fun send() {
            val question = draft.trim()
            if (question.isBlank() || busy || !loaded) return
            messages += ChatMessage(true, question)
            val reply = engine.answer(question, LocalAgentContext(settings.childName, records, tasks, kr.mom.probe.data.NoticeDecisionEngine.childProfile(settings)))
            messages += ChatMessage(false, reply.message)
            draft = ""
            keyboard?.hide()
            reply.proposedTask?.let { task ->
                scope.launch {
                    busy = true
                    try {
                        val reminder = reply.proposedRemindAt?.takeIf { TaskReminderScheduler.canDeliver(this@AgentActivity) }
                        val saved = withContext(Dispatchers.IO) { taskStore.addTask(task, dueAt = reply.proposedDueAt, remindAt = reminder) }
                        error = null
                        if (saved == null) {
                            messages += ChatMessage(false, "이미 부탁 목록에 있는 내용이에요.")
                        } else {
                            undoTask = saved
                            val alarmText = if (saved.remindAt != null) " 요청한 시각 알림도 함께 저장했어요." else " 별도 알림은 만들지 않았어요."
                            messages += ChatMessage(false, "부탁 목록에 저장했어요.$alarmText")
                        }
                    } catch (failure: Exception) {
                        if (failure is CancellationException) throw failure
                        error = if (failure is IllegalArgumentException || failure is IllegalStateException || failure is IOException) {
                            failure.message
                        } else {
                            "부탁을 저장하지 못했어요. 다시 시도해주세요."
                        }
                    } finally {
                        busy = false
                    }
                }
            }
        }

        LaunchedEffect(allowed) {
            loaded = false
            if (allowed) loaded = storeOperation { taskStore.load() }
            else undoTask = null
        }
        LaunchedEffect(messages.size) {
            if (messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
        }

        Column(
            Modifier.fillMaxSize().background(Clay.Background).safeDrawingPadding().imePadding()
                .padding(horizontal = 20.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TextButton(onClick = { finish() }) { Text("닫기") }
                Text("모모", style = MaterialTheme.typography.titleMedium, color = Clay.Green)
                TextButton(onClick = { startActivity(Intent(this@AgentActivity, AssistantTasksActivity::class.java)) }) { Text("부탁 목록") }
            }

            AgentCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BellMascot(Modifier.size(width = 54.dp, height = 64.dp))
                    Spacer(Modifier.size(12.dp))
                    Column {
                        Text("엄마 곁의 로컬 에이전트", style = MaterialTheme.typography.titleLarge)
                        Text("가족 정보는 이 기기 안에서만 살펴봐요.", style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))

            when {
                !ready -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                !allowed -> ClayCard(Modifier.fillMaxWidth()) {
                    Text("처음 설정을 마쳐야 모모가 저장된 알림과 부탁을 안전하게 살펴볼 수 있어요.")
                    TextButton(onClick = {
                        startActivity(Intent(this@AgentActivity, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
                        finish()
                    }) { Text("설정하러 가기") }
                }
                else -> {
                    LazyColumn(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        state = listState,
                        contentPadding = PaddingValues(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(messages) { message -> ChatBubble(message) }
                    }
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    undoTask?.let { saved ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("방금 저장한 부탁", style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
                            TextButton(enabled = !busy, onClick = {
                                scope.launch {
                                    if (storeOperation { taskStore.delete(saved.id) }) {
                                        messages += ChatMessage(false, "방금 저장한 부탁을 취소했어요.")
                                        undoTask = null
                                    }
                                }
                            }) { Text("취소") }
                        }
                    }
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { if (it.length <= MAX_QUESTION_LENGTH) draft = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("모모에게 묻기") },
                        placeholder = { Text("예: 내일 뭐 챙겨야 해?") },
                        minLines = 1,
                        maxLines = 3,
                        enabled = loaded && !busy,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { send() }),
                        supportingText = { Text("${draft.length}/$MAX_QUESTION_LENGTH · 로컬 저장은 바로 하고 취소할 수 있어요") },
                    )
                    AgentButton(
                        text = "모모에게 보내기",
                        modifier = Modifier.padding(top = 8.dp, bottom = 12.dp),
                        enabled = loaded && !busy && draft.isNotBlank(),
                        onClick = ::send,
                    )
                }
            }
        }

    }

    @Composable
    private fun ChatBubble(message: ChatMessage) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start,
        ) {
            Text(
                text = message.text,
                modifier = Modifier.fillMaxWidth(.88f).background(
                    if (message.fromUser) Clay.Green else Clay.Paper,
                    RoundedCornerShape(22.dp),
                ).padding(horizontal = 16.dp, vertical = 13.dp),
                color = if (message.fromUser) Color.White else Clay.Ink,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }

    private data class ChatMessage(val fromUser: Boolean, val text: String)

    companion object {
        private const val MAX_QUESTION_LENGTH = 500
    }
}
