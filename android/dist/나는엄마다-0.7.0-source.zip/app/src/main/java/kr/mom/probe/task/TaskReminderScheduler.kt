package kr.mom.probe.task

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import kr.mom.probe.R
import kr.mom.probe.data.ProbeRepository

/** Owns one immutable, explicit alarm per assistant task. */
object TaskReminderScheduler {
    private const val ACTION_FIRE = "kr.mom.probe.task.FIRE_REMINDER"
    private const val EXTRA_TASK_ID = "taskId"
    private const val PREFS = "assistant-task-reminders"
    private const val SCHEDULED_IDS = "scheduledIds"
    const val CHANNEL = "mom-task-reminders"

    fun canDeliver(context: Context): Boolean {
        if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false
        val manager = context.getSystemService(NotificationManager::class.java)
        ensureChannel(manager)
        return manager.areNotificationsEnabled() && manager.getNotificationChannel(CHANNEL)?.importance != NotificationManager.IMPORTANCE_NONE
    }

    private fun ensureChannel(manager: NotificationManager) {
        manager.createNotificationChannel(NotificationChannel(
            CHANNEL,
            "모모의 부탁 알림",
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = "직접 정한 시간 무렵에 챙길 일을 알려줘요"
            lockscreenVisibility = Notification.VISIBILITY_PRIVATE
            enableVibration(true)
        })
    }

    fun sync(context: Context, tasks: List<AssistantTask>) {
        val app = context.applicationContext
        val active = tasks.filter { !it.completed && !it.suspended && it.remindAt != null }.associateBy { it.id }
        val preferences = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val previous = preferences.getStringSet(SCHEDULED_IDS, emptySet()).orEmpty().toSet()
        (previous - active.keys).forEach { cancel(app, it) }
        active.values.forEach { schedule(app, it) }
        preferences.edit().putStringSet(SCHEDULED_IDS, active.keys.toSet()).apply()
    }

    fun cancel(context: Context, taskId: String) {
        context.getSystemService(AlarmManager::class.java).cancel(pending(context, taskId))
        context.getSystemService(NotificationManager::class.java).cancel(notificationId(taskId))
    }

    /** Rehydrates encrypted tasks after boot, then recreates every outstanding alarm. */
    fun restore(context: Context) {
        val app = context.applicationContext
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch { restoreNow(app) }
    }

    internal suspend fun restoreNow(context: Context) {
        withTimeout(10_000) {
            ProbeRepository.get(context).isReady.first { it }
            val store = AssistantTaskStore.get(context)
            store.load()
            sync(context, store.tasks.value)
        }
    }

    internal fun notify(context: Context, task: AssistantTask): Boolean {
        if (task.completed || task.suspended || task.remindAt == null) return false
        if (!canDeliver(context)) return false
        val manager = context.getSystemService(NotificationManager::class.java)

        val open = PendingIntent.getActivity(
            context,
            notificationId(task.id),
            Intent(context, AssistantTasksActivity::class.java)
                .setAction("kr.mom.probe.task.OPEN_REMINDER")
                .putExtra(EXTRA_TASK_ID, task.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val publicVersion = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("나는 엄마다")
            .setContentText("확인할 부탁이 있어요")
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("모모가 부탁을 알려드려요")
            .setContentText(task.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(task.text))
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        return try {
            manager.notify(notificationId(task.id), notification)
            true
        } catch (_: SecurityException) {
            false
        }
    }

    private fun schedule(context: Context, task: AssistantTask) {
        val remindAt = task.remindAt ?: return
        val manager = context.getSystemService(AlarmManager::class.java)
        val operation = pending(context, task.id)
        manager.cancel(operation)
        try {
            if (manager.canScheduleExactAlarms()) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, remindAt, operation)
            } else {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, remindAt, operation)
            }
        } catch (_: SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, remindAt, operation)
        }
    }

    private fun pending(context: Context, taskId: String): PendingIntent = PendingIntent.getBroadcast(
        context,
        taskId.hashCode(),
        Intent(context, TaskReminderReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra(EXTRA_TASK_ID, taskId),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun notificationId(taskId: String): Int = taskId.hashCode() xor 0x4D4F4D4F

    internal fun isFire(intent: Intent): Boolean = intent.action == ACTION_FIRE
    internal fun taskId(intent: Intent): String? = intent.getStringExtra(EXTRA_TASK_ID)
}

class TaskReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val result = goAsync()
            CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
                try {
                    TaskReminderScheduler.restoreNow(context.applicationContext)
                } catch (_: Exception) {
                    // A later app launch/save retries synchronization.
                } finally {
                    result.finish()
                }
            }
            return
        }
        if (!TaskReminderScheduler.isFire(intent)) return
        val taskId = TaskReminderScheduler.taskId(intent) ?: return
        val result = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                val repository = ProbeRepository.get(context)
                withTimeout(7_000) { repository.isReady.first { it } }
                val store = AssistantTaskStore.get(context)
                store.load()
                val task = store.tasks.value.firstOrNull { it.id == taskId && !it.completed && !it.suspended && it.remindAt != null } ?: return@launch
                if (!TaskReminderScheduler.canDeliver(context)) {
                    if (task.reminderAttempts >= 2) store.consumeReminder(taskId)
                    else store.rescheduleReminder(taskId, System.currentTimeMillis() + 15 * 60_000L)
                    return@launch
                }
                store.consumeReminder(taskId)?.let { fired ->
                    if (!TaskReminderScheduler.notify(context, fired)) {
                        if (fired.reminderAttempts < 2) store.rescheduleReminder(taskId, System.currentTimeMillis() + 15 * 60_000L)
                    }
                }
            } catch (_: Exception) {
                // Do not expose stale task contents when local state cannot be verified.
            } finally {
                result.finish()
            }
        }
    }
}
