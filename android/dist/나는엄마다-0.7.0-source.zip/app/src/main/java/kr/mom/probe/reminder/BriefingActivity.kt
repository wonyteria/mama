package kr.mom.probe.reminder

import android.content.Intent
import android.app.KeyguardManager
import android.app.NotificationManager
import android.view.WindowManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale
import kr.mom.probe.MainActivity
import kr.mom.probe.BuildConfig
import kr.mom.probe.task.AssistantTaskStore
import kr.mom.probe.task.AssistantTasksActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kr.mom.probe.data.ProbeRepository
import kr.mom.probe.data.ProbeRules
import kr.mom.probe.data.NoticeDecisionEngine
import kr.mom.probe.ui.displayTime
import kr.mom.probe.ui.MomTheme
import kr.mom.probe.ui.AgentButton
import kr.mom.probe.ui.AgentCard
import kr.mom.probe.ui.BellMascot
import kr.mom.probe.ui.Clay

class BriefingActivity : ComponentActivity() {
    private var speech: TextToSpeech? = null
    private var speechReady by mutableStateOf(false)
    private var unlocked by mutableStateOf(false)
    override fun onResume() {
        super.onResume()
        unlocked = !getSystemService(KeyguardManager::class.java).isKeyguardLocked
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!BuildConfig.DEBUG) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        if (intent.getBooleanExtra("ringing", false)) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        speech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) speechReady = (speech?.setLanguage(Locale.KOREAN) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= 0
        }
        setContent {
            MomTheme {
                val repository = remember { ProbeRepository.get(this) }
                val ready by repository.isReady.collectAsState()
                val settings by repository.settings.collectAsState()
                val records by repository.records.collectAsState()
                val error by repository.lastError.collectAsState()
                val taskStore = remember { AssistantTaskStore.get(this) }
                val tasks by taskStore.tasks.collectAsState()
                var taskError by remember { mutableStateOf(false) }
                var taskLoading by remember { mutableStateOf(true) }
                val demo = intent.getBooleanExtra(BriefingReminders.DEMO, false)
                val allowed = unlocked && ready && settings.consent && settings.consentVersion == ProbeRules.CONSENT_VERSION && settings.onboardingDone && error == null
                LaunchedEffect(allowed) {
                    if (allowed) {
                        taskLoading = true
                        try { withContext(Dispatchers.IO) { taskStore.load() }; taskError = false } catch (_: Exception) { taskError = true }
                        finally { taskLoading = false }
                    }
                }
                val pending = if (allowed && !taskError) BriefingReminders.briefingTasks(tasks) else emptyList()
                val linkedNotificationIds = if (allowed && !taskError) tasks.mapNotNull { it.sourceNotificationId }.toSet() else emptySet()
                val unseen = if (allowed) remember(records, settings, tasks) { BriefingReminders.unseenRecords(this, repository, tasks) } else emptyList()
                val child = remember(settings.schoolGrade, settings.schoolLevel, settings.schoolName) { NoticeDecisionEngine.childProfile(settings) }
                val noticeRows = remember(unseen, child) {
                    unseen.map { it to NoticeDecisionEngine.decide(it, child) }
                        .filter { it.second.isRequiredForChild() }
                        .filter { it.second.source.notificationId !in linkedNotificationIds }
                        .sortedWith(compareBy<Pair<kr.mom.probe.data.ProbeRecord, kr.mom.probe.data.NoticeDecision>> { it.second.action?.dueAt ?: Long.MAX_VALUE }
                            .thenByDescending { it.first.receivedAt })
                }
                val shownNoticeRows = remember(noticeRows) { noticeRows.take(3) }
                val count = noticeRows.size
                val noticeSummaries = remember(shownNoticeRows) {
                    shownNoticeRows.map { (record, decision) ->
                        val action = decision.action
                        val due = action?.dueAt?.let { " · ${displayTime(it)}" }
                            ?: action?.whenText?.let { " · 원문 $it" }.orEmpty()
                        "${action?.label ?: record.title.ifBlank { "내용 확인 필요" }}$due"
                    }
                }
                val text = when {
                    !unlocked -> "모모가 알려드릴 소식이 있어요. 잠금을 풀고 확인해 주세요."
                    !allowed -> "첫 설정을 마친 뒤 다시 불러주세요."
                    demo -> "비서 알림 미리보기예요. 앞으로 정한 시간에 새로 모인 알림을 알려드릴게요."
                    taskLoading -> "부탁을 확인하고 있어요."
                    taskError -> "부탁을 불러오지 못했어요. 새 알림은 ${count}개예요."
                    count == 0 && pending.isEmpty() -> "새 알림과 남은 부탁이 없어요. 연결된 모든 앱과 사이트를 확인했다는 뜻은 아니에요."
                    else -> buildString {
                        append("오늘 챙길 내용을 한 번에 정리했어요.")
                        noticeSummaries.forEach { append("\n• $it") }
                        pending.take((3 - noticeSummaries.size).coerceAtLeast(0)).forEach { append("\n• 부탁: ${it.text}") }
                        val summarized = noticeSummaries.size + pending.take((3 - noticeSummaries.size).coerceAtLeast(0)).size
                        val remaining = count + pending.size - summarized
                        if (remaining > 0) append("\n그 밖에 새 소식과 부탁 ${remaining}개가 더 있어요.")
                    }
                }
                LaunchedEffect(allowed, demo, taskLoading, taskError, shownNoticeRows) {
                    if (allowed && !demo && !taskLoading && !taskError && shownNoticeRows.isNotEmpty()) {
                        BriefingReminders.markSeenRecords(this@BriefingActivity, shownNoticeRows.map { it.first })
                    }
                }
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.safeDrawingPadding().padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                        TextButton(onClick = { finish() }) { Text("닫기") }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(if (demo) "비서 미리보기" else "모모의 브리핑", style = MaterialTheme.typography.headlineMedium)
                                Text("엄마가 정한 시간에 찾아왔어요", color = Clay.Muted, style = MaterialTheme.typography.bodySmall)
                            }
                            BellMascot(Modifier.size(width = 64.dp, height = 78.dp))
                        }
                        AgentCard(Modifier.fillMaxWidth()) {
                            Text(if (unlocked) "제가 지금 챙길게요" else "확인할 소식이 있어요", color = Clay.CoralDark, style = MaterialTheme.typography.bodyMedium)
                            Text(text, style = MaterialTheme.typography.titleLarge)
                        }
                        if (!unlocked) Button(onClick = {
                            getSystemService(KeyguardManager::class.java).requestDismissKeyguard(this@BriefingActivity, object : KeyguardManager.KeyguardDismissCallback() {
                                override fun onDismissSucceeded() { unlocked = true }
                            })
                        }, modifier = Modifier.fillMaxWidth()) { Text("잠금 풀고 확인") }
                        AgentButton("소리로 듣기", enabled = allowed && speechReady && (!taskLoading || demo)) {
                            stopAlarm(); speech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "briefing")
                        }
                        if (!speechReady) Text("한국어 음성 엔진이 준비되지 않았어요. 화면으로 확인할 수 있어요.", style = MaterialTheme.typography.bodySmall)
                        if (allowed && !demo) {
                            if (taskError) Text("부탁을 불러오지 못했어요. 앱에서 다시 확인해 주세요.")
                            OutlinedButton(onClick = { startActivity(Intent(this@BriefingActivity, AssistantTasksActivity::class.java)); finish() }, modifier = Modifier.fillMaxWidth()) { Text("부탁 확인하기") }
                            OutlinedButton(onClick = { startActivity(Intent(this@BriefingActivity, MainActivity::class.java)); finish() }, modifier = Modifier.fillMaxWidth()) { Text("앱에서 알림 확인") }
                            Text("조금 뒤 다시 알려드릴까요?", style = MaterialTheme.typography.titleMedium)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(10, 30, 60).forEach { minutes ->
                                    OutlinedButton(onClick = {
                                        BriefingReminders.snooze(this@BriefingActivity, intent.getIntExtra("slot", 0), minutes)
                                        finish()
                                    }, modifier = Modifier.weight(1f)) { Text("${minutes}분") }
                                }
                            }
                            Text("브리핑을 열면 화면에 보여준 새 소식만 확인 처리해요. 부탁 완료와 기록 삭제는 하지 않아요.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
    private fun stopAlarm() { getSystemService(NotificationManager::class.java).cancel(710 + intent.getIntExtra("slot", 0)) }
    override fun onStop() { stopAlarm(); speech?.stop(); super.onStop() }
    override fun onDestroy() { speech?.shutdown(); speech = null; super.onDestroy() }
}
