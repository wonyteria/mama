package kr.mom.probe.reminder

import android.app.Application
import androidx.test.core.app.ApplicationProvider
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = Application::class)
class BriefingRemindersTest {
    private val context get() = ApplicationProvider.getApplicationContext<Application>()

    @Before @After fun clear() {
        context.getSharedPreferences("briefing-reminders", Application.MODE_PRIVATE).edit().clear().commit()
    }

    @Test fun defaultsPreserveExistingUserTimeAndEnableMissingEvening() {
        context.getSharedPreferences("briefing-reminders", Application.MODE_PRIVATE).edit()
            .putBoolean("enabled0", true).putInt("hour0", 8).putInt("minute0", 15).commit()

        assertTrue(BriefingReminders.enableDefaults(context))
        assertEquals(BriefingTime(true, 8, 15, false), BriefingReminders.read(context, 0))
        assertEquals(BriefingTime(true, 20, 30, false), BriefingReminders.read(context, 1))
    }

    @Test fun seenStateUsesOnlyDisplayedRecordRevisions() {
        val hidden = record("hidden", 10L)
        val shown = listOf(record("shown-4", 40L), record("shown-3", 30L), record("shown-2", 20L))
        val seen = BriefingReminders.seenRevisionIdsFor(shown)

        assertTrue(hidden.id !in seen)
        assertEquals(3, seen.size)
    }

    @Test fun briefingTaskProjectionExcludesSuspendedExpiredAndDistantTasks() {
        val now = 1_000L
        val visible = kr.mom.probe.task.AssistantTask("visible", "내일 제출", false, 10L, dueAt = now + 86_400_000L)
        val localNoDue = kr.mom.probe.task.AssistantTask("local", "물통", false, 11L)
        val suspended = kr.mom.probe.task.AssistantTask("suspended", "정정 전", false, 12L, dueAt = now + 86_400_000L, suspended = true)
        val expired = kr.mom.probe.task.AssistantTask("expired", "어제", false, 13L, dueAt = now - 1L)
        val distant = kr.mom.probe.task.AssistantTask("distant", "한참 뒤", false, 14L, dueAt = now + 9 * 86_400_000L)
        val completed = kr.mom.probe.task.AssistantTask("done", "완료", true, 15L)

        val projected = BriefingReminders.briefingTasks(listOf(suspended, expired, distant, completed, localNoDue, visible), now)

        assertEquals(listOf("visible", "local"), projected.map { it.id })
        assertFalse(projected.any { it.suspended || it.completed })
    }

    private fun record(id: String, receivedAt: Long) = kr.mom.probe.data.ProbeRecord(
        id = id, packageName = "pkg", appLabel = "학교", postedAt = receivedAt, receivedAt = receivedAt,
        title = id, text = "준비물: 물통. 내일 오전 9시까지", bigText = "", textLines = emptyList(),
        subText = null, summaryText = null, category = null, channelId = null, notificationId = 1,
        notificationKey = "key-$id", isOngoing = false, isGroupSummary = false, rawHash = "hash",
    )
}
