package kr.mom.probe.task

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AssistantTaskStoreTest {
    @Test fun consumingReminderClearsItAndReturnsOriginalTaskOnce() {
        val reminder = AssistantTask("one", "물통 챙기기", false, 10L, remindAt = 20L)
        val other = AssistantTask("two", "회신하기", false, 11L, remindAt = 30L)

        val (afterFirst, fired) = AssistantTaskStore.consumeReminderFrom(listOf(reminder, other), "one")
        val (afterSecond, firedAgain) = AssistantTaskStore.consumeReminderFrom(afterFirst, "one")

        assertEquals(reminder, fired)
        assertNull(afterFirst.first { it.id == "one" }.remindAt)
        assertEquals(30L, afterFirst.first { it.id == "two" }.remindAt)
        assertNull(firedAgain)
        assertEquals(afterFirst, afterSecond)
    }

    @Test fun completedTaskReminderCannotBeConsumed() {
        val completed = AssistantTask("done", "준비 완료", true, 10L, remindAt = 20L)
        val (unchanged, fired) = AssistantTaskStore.consumeReminderFrom(listOf(completed), "done")
        assertEquals(listOf(completed), unchanged)
        assertNull(fired)
    }

    @Test fun automaticNoticeRevisionSuspendsPreviousAutomaticTaskOnly() {
        val old = AssistantTask("old", "금요일 제출", false, 10L, sourceNotificationId = "source", sourceRevisionId = "rev1", sourceKind = AssistantTaskSource.AUTO_NOTICE, dueAt = 100L, remindAt = 90L)
        val user = AssistantTask("user", "직접 확인한 제출", false, 11L, sourceNotificationId = "manual", sourceRevisionId = "rev1", sourceKind = AssistantTaskSource.USER_CONFIRMED_NOTICE)

        val reconciled = AssistantTaskStore.reconcileAutomaticRevisionForTest(
            listOf(old, user),
            sourceNotificationId = "source",
            sourceRevisionId = "rev2",
        )
        val suspended = reconciled.first { it.id == "old" }

        assertFalse(suspended.completed)
        assertTrue(suspended.suspended)
        assertEquals("rev2", suspended.sourceRevisionId)
        assertNull(suspended.remindAt)
        assertFalse(reconciled.first { it.id == "user" }.completed)
    }

    @Test fun suspendedAutomaticTaskDoesNotLookCompletedToNotifierProjection() {
        val suspended = AssistantTask(
            "old",
            "정정 전 제출",
            false,
            10L,
            sourceNotificationId = "source",
            sourceRevisionId = "rev2",
            sourceKind = AssistantTaskSource.AUTO_NOTICE,
            suspended = true,
        )

        val completedSource = listOf(suspended).any { it.sourceNotificationId == "source" && it.completed }

        assertFalse(completedSource)
    }
}
