package kr.mom.probe.connector

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kr.mom.probe.data.ProbeRepository

/** Checks cookie presence only; it never treats cookies as data-read success. */
class WebsiteHealthWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val probe = ProbeRepository.get(applicationContext)
        if (!probe.isReady.value || !probe.settings.value.consent) return Result.success()
        val connectors = ConnectorRepository.get(applicationContext)
        connectors.state.value.sites.values
            .filter { it.id == "ealimi-web" || it.id == "hiclass-web" }
            .filter { it.status == ConnectionStatus.SESSION_READY || it.status == ConnectionStatus.CONNECTED }
            .forEach { connection ->
                val definition = ConnectorCatalog.site(connection.id) ?: return@forEach
                if (!WebsiteSessionManager.hasStoredSession(definition)) connectors.requireReauth(connection.id)
            }
        return Result.success()
    }
}
