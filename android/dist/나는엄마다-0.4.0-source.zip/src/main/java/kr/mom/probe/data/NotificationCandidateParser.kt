package kr.mom.probe.data

data class NotificationCandidate(
    val kind: Kind,
    val items: List<String>,
    val dueText: String?,
    val confidence: String = "확인 필요",
) {
    enum class Kind { PREPARE, SUBMIT, DEADLINE }
}

/** Small deterministic hint parser. It never creates an Action or schedules an alarm. */
object NotificationCandidateParser {
    private val deadline = Regex("(오늘|내일|모레|이번 주|다음 주)(?:\\s*(오전|오후)?\\s*(\\d{1,2})시)?")
    private val trigger = Regex("준비물|준비해야|챙겨|제출|신청|마감|기한|납부")

    fun parse(record: ProbeRecord): NotificationCandidate? {
        val source = listOf(record.title, record.bigText, record.text, record.textLines.joinToString(" "))
            .filter { it.isNotBlank() }.joinToString(" ").replace(Regex("\\s+"), " ").trim()
        if (source.isBlank() || !trigger.containsMatchIn(source)) return null
        val due = deadline.find(source)?.value
        val kind = when {
            source.contains("제출") || source.contains("신청") || source.contains("납부") -> NotificationCandidate.Kind.SUBMIT
            source.contains("마감") || source.contains("기한") -> NotificationCandidate.Kind.DEADLINE
            else -> NotificationCandidate.Kind.PREPARE
        }
        val items = extractItems(source)
        return NotificationCandidate(kind, items, due)
    }

    private fun extractItems(source: String): List<String> {
        val marker = listOf("준비물", "챙길 것", "준비해야 할 것").firstOrNull { source.contains(it) } ?: return emptyList()
        val tail = source.substringAfterLast(marker).substringBefore(".").substringBefore("\n").trim()
            .removePrefix(":").trim()
        if (tail.isBlank()) return emptyList()
        return tail.split(',', '·', '/', '•').map { it.trim(' ', ':', '-', '–') }
            .filter { it.length in 1..40 }.take(8)
    }
}
