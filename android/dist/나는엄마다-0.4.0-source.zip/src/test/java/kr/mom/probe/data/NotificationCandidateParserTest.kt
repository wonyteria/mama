package kr.mom.probe.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class NotificationCandidateParserTest {
    private fun record(title: String, text: String) = ProbeRecord(
        id = "id", packageName = "pkg", appLabel = "학교", postedAt = 1, receivedAt = 1,
        title = title, text = text, bigText = "", textLines = emptyList(), subText = null,
        summaryText = null, category = null, channelId = null, notificationId = 1,
        notificationKey = "key", isOngoing = false, isGroupSummary = false, rawHash = "hash",
    )

    @Test fun findsPrepareItemsAndDueHint() {
        val candidate = NotificationCandidateParser.parse(record("체험학습 준비물", "준비물: 도시락, 물통, 모자. 내일 오전 9시까지"))
        assertNotNull(candidate)
        assertEquals(listOf("도시락", "물통", "모자"), candidate!!.items)
        assertEquals("내일 오전 9시", candidate.dueText)
    }

    @Test fun doesNotInventCandidateForInformationalText() {
        assertNull(NotificationCandidateParser.parse(record("학교 안내", "다음 주 체험학습이 진행됩니다.")))
    }
}
