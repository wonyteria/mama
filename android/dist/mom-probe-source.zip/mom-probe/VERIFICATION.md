# MOM PROBE 0.1.0 — 구현 검증

2026-09-13 · G0 개발용 APK · 클레이모피즘 화면

## 확인한 결과

| 검증 | 결과 | 증거 |
|---|---|---|
| Android debug APK 빌드 | 성공 | `:app:assembleDebug` |
| 자동 테스트 | **17개 통과, 실패 0** | `app/build/reports/tests/testDebugUnitTest/index.html` |
| 정적 검사 | 오류 0, 경고 18 | `app/build/reports/lint-results-debug.html` |
| APK 서명 | APK Signature Scheme v2 검증 성공 | apksigner verify, Android Debug 인증서 |
| 설치 대상 | min SDK33 / target36 | aapt2 manifest badging |
| 네트워크 경계 | APK에 INTERNET 권한 없음 | 최종 병합 Manifest 검사 |
| 화면 렌더링 | 실제 Compose 5개 상태 PNG 생성·육안 검수 | `app/build/reports/screenshots/` |
| 코드 교차 검수 | 지적한 복원·저장·초기 수집·오류 복구 문제 수정 확인 | 아래 수정 목록 |

최종 전체 검증 명령: `scripts/build.ps1 -Tasks @(':app:assembleDebug', ':app:testDebugUnitTest', ':app:lintDebug')`.

Windows 제한 프로세스의 Guava 임시폴더 ACL 때문에 화면 테스트 런타임이 실패하여, 같은 로컬 테스트를 표준 프로세스 권한으로 재실행했다. 테스트 홈/임시 경로는 `app/build` 안으로 지정했다. 테스트를 생략하거나 실패를 통과로 처리하지 않았다.

## 자동 테스트 구성

- ProbeRulesTest 3개: 수집 동의·설정·실제 권한·선택 앱 gate, 제외 대상, revision/14일 경계.
- ProbeExporterTest 6개: 이름·전화·이메일·긴번호 가림, JSON/CSV escaping, 수식 주입 방지, 직접 식별자 제외, 잘림 표시와 시각 보존.
- ProbeCaptureReadinessTest 3개: 초기 설정 복원 기다리기, 대기 중 정책 변경 시 폐기, 대기 시간 제한.
- ProbeScreensRenderTest 5개: 홈 설정 복구 CTA, 동의 전 시작 차단, 명시 앱 선택, 이름 필수 검증, 320×640dp/글꼴1.5배에서 공백·길이 검증과 CTA 스크롤 접근.

UI 테스트는 Android34 Robolectric native graphics에서 프로덕션 Composable을 직접 렌더링한다. Windows PixelCopy가 완료되지 않아 실제 Activity의 view tree를 Android Canvas에 그려 PNG를 만들었다. **HTML 복제 화면이 아니지만, 물리 휴대폰이나 에뮬레이터 캡처도 아니다.** 그림자·OS 키보드·권한 화면은 실제 기기에서 다시 확인해야 한다.

## 시각 검수

참고는 `design/reference.png`, 구현은 `app/build/reports/screenshots/home-setup.png`다. 첫 비교에서 약한 그림자와 폰트 의존 장식 아이콘을 수정했다. 최종 비교는 92/100, 기준90 이상. 이 점수는 모델의 디자인 검수 판단이며 사용자 만족도나 실측 접근성 점수가 아니다.

크림/세이지/살구 팔레트, 볼록한 카드, 둥근 버튼, 잎 마크·종 마스코트를 확인했다. 글꼴 확대 시 장식이 본문을 밀지 않도록 마스코트를 숨긴다. 모든 긴 화면은 스크롤하며, 캡처된 큰 글꼴 상태에서 입력창과 다음 버튼이 접근 가능하다.

## 수정한 주요 결함

- 권한 설정을 확인하거나 앱 선택을 편집한 것만으로 사용자가 멈춘 수집을 다시 켜던 경로 분리.
- 설정/저장 실패를 Boolean으로 반환하여 실패 후 다음 화면으로 이동하지 않도록 수정.
- Activity 재생성 때 화면 복원, 반출 자료는 ViewModel 메모리에서 회전까지 유지. 프로세스가 사라지면 재검토 안내.
- 파일 저장 중 중단/실패 시 새로 만든 문서 정리 시도. 제공자가 삭제를 지원하지 않으면 빈 파일이 남을 수 있음.
- 설정 복원 전 첫 알림을 버리지 않도록 짧게 대기하고 정책 epoch 재검사.
- 기록 조회 실패 시 관찰을 재구독하고, 실패 상태를 숨기지 않으며 수집을 중단.
- 전체 삭제 직전의 오래된 DB emission이 삭제된 원문을 다시 표시하지 않도록 잠금 안에서 재조회.
- 기기에서 제거된 앱은 복귀 시 선택 목록에서 제외하여 수집 준비 상태를 오표시하지 않도록 처리.

## 남은 경고와 미검증

Lint 경고18개는 AGP/라이브러리의 새 버전 안내17개와 Application context를 보관하는 singleton에 대한 StaticFieldLeak 경고1개다. 현재 repository는 Activity/Service가 아니라 `applicationContext`를 보관한다. 선택한 버전 조합을 빌드·테스트했으며 이번 작업에서 최신 버전으로 일괄 교체하지 않았다.

현재 PC에 Android 에뮬레이터 가속 드라이버가 없다. 소프트웨어 실행의 GPU/코어 조합 3가지를 시도했지만 offline 정지/종료하여 에뮬레이터 실행 검증은 실패했다. 해당 실행 프로세스는 정리했고 드라이버 설치·재부팅은 하지 않았다.

따라서 다음은 **미검증**이다.

- 실제 Galaxy Android13~16 설치 및 OS 권한 화면 왕복.
- Android Keystore/Room의 물리 기기 재부팅·앱 프로세스 종료 후 유지와 복구.
- 실제 학교/학원 앱의 알림 내용 노출, 알림 접근 제한, 백그라운드 수집 안정성.
- 5~10명/7~14일/300건 실험과 원본 공지 대비 정보 확보율.
- Google Play 내부 테스트 배포, 정식 서명, 운영 개인정보 고지 검토.

APK는 설치 가능한 개발 산출물이다. 위 미검증이 해소되기 전 G0 통과나 V0 제품 완성으로 선언하지 않는다. AI 요약·일정 등록·자동 리마인더는 아직 제공하지 않는다.
