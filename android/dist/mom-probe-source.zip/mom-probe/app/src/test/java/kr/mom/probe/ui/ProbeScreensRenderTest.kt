package kr.mom.probe.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertIsOn
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextReplacement
import androidx.compose.ui.unit.Density
import java.io.File
import kr.mom.probe.data.ProbeSettings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

/**
 * Renders production composables using Android native graphics, without opening the
 * repository, Keystore, notification listener, or an external app. These screenshots
 * are UI evidence only; fixture source apps do not prove real package discovery.
 */
@RunWith(RobolectricTestRunner::class)
@Config(
    sdk = [34],
    application = Application::class,
    qualifiers = "ko-rKR-w412dp-h892dp-xhdpi",
)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class ProbeScreensRenderTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()

    @Test
    fun homeWithoutSetupShowsRecoveryAndNoInventedRecords() {
        var setupRequests = 0
        render {
            Scaffold(
                bottomBar = { ProbeBottomBar(current = "home", onSelect = {}) },
                containerColor = Clay.Background,
            ) { padding ->
                Box(Modifier.fillMaxSize().padding(padding)) {
                    HomeScreen(
                        settings = ProbeSettings(consent = true, onboardingDone = true),
                        records = emptyList(),
                        access = false,
                        connected = false,
                        onSetup = { setupRequests++ },
                        onInbox = {},
                        onRecord = {},
                    )
                }
            }
        }
        compose.onNodeWithText("마지막 준비를 도와드릴게요").assertIsDisplayed()
        compose.onNodeWithTag("resume-setup").assertIsEnabled()
        screenshot("home-setup")
        compose.onNodeWithTag("resume-setup").performClick()
        compose.runOnIdle { assertEquals(1, setupRequests) }
        compose.onNodeWithText("아직 도착한 알림이 없어요").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun welcomeRequiresConsentBeforeStarting() {
        var starts = 0
        render { WelcomeScreen(busy = false, onStart = { starts++ }, onPolicy = {}) }
        screenshot("welcome")
        compose.onNodeWithTag("start").performScrollTo().assertIsNotEnabled()
        val consent = compose.onNodeWithText(
            "설명을 확인했고, 이 기기에서의 알림 수집 테스트에 동의해요. (필수)",
        )
        consent.performScrollTo().performClick().assertIsOn()
        compose.onNodeWithTag("start").performScrollTo().assertIsEnabled().performClick()
        compose.runOnIdle { assertEquals(1, starts) }
    }

    @Test
    fun sourceSelectionSavesOnlyUserChosenFixture() {
        var saved: Set<String>? = null
        val fixtureApps = listOf(
            SourceApp("test.fixture.school", "테스트 학교 앱", "화면 테스트용 · 설치 확인 아님", "학"),
            SourceApp("test.fixture.academy", "테스트 학원 앱", "화면 테스트용 · 설치 확인 아님", "원"),
        )
        render {
            SourcesScreen(
                apps = fixtureApps,
                initial = emptySet(),
                busy = false,
                onSave = { saved = it },
                onBack = {},
                onSkip = {},
                onRefresh = {},
            )
        }
        compose.onNodeWithTag("save-sources").assertIsNotEnabled()
        compose.onNodeWithText("테스트 학교 앱").performClick().assertIsOn()
        screenshot("sources-fixture")
        compose.onNodeWithTag("save-sources").performScrollTo().assertIsEnabled().performClick()
        compose.runOnIdle { assertEquals(setOf("test.fixture.school"), saved) }
    }

    @Test
    fun childScreenStartsWithEmptyDisabledInput() {
        render { ChildScreen(initial = "", busy = false, onSave = {}, onBack = {}) }
        compose.onNodeWithTag("child-name").assertIsDisplayed()
        compose.onNodeWithTag("save-child").assertIsNotEnabled()
        screenshot("child")
    }

    @Test
    @Config(qualifiers = "ko-rKR-w320dp-h640dp-xhdpi")
    fun childRemainsReachableAtSmallWidthAndLargeText() {
        var savedName: String? = null
        render(fontScale = 1.5f) {
            ChildScreen(initial = "", busy = false, onSave = { savedName = it }, onBack = {})
        }
        val input = compose.onNodeWithTag("child-name")
        val next = compose.onNodeWithTag("save-child")
        next.performScrollTo().assertIsNotEnabled()
        input.performScrollTo().performTextReplacement("   ")
        next.performScrollTo().assertIsNotEnabled()
        input.performScrollTo().performTextReplacement("가".repeat(21))
        next.performScrollTo().assertIsNotEnabled()
        input.performScrollTo().performTextReplacement("  우리 아이  ")
        input.assertTextContains("  우리 아이  ")
        next.performScrollTo().assertIsDisplayed().assertIsEnabled()
        screenshot("child-small-large-text")
        next.performClick()
        compose.runOnIdle { assertEquals("우리 아이", savedName) }
    }

    private fun render(fontScale: Float = 1f, content: @Composable () -> Unit) {
        compose.setContent {
            val density = LocalDensity.current
            CompositionLocalProvider(LocalDensity provides Density(density.density, fontScale)) {
                MomTheme {
                    Surface(modifier = Modifier.fillMaxSize(), color = Clay.Background) { content() }
                }
            }
        }
        compose.waitForIdle()
    }

    private fun screenshot(name: String) {
        compose.waitForIdle()
        val directory = File("build/reports/screenshots").apply { mkdirs() }
        val file = File(directory, "$name.png")
        // Compose captureToImage uses PixelCopy, whose platform callback does not
        // complete in this Windows Robolectric runtime. Draw the actual Activity
        // view tree to a native Android Canvas instead; no HTML or replica UI.
        val bitmap = compose.runOnIdle {
            val decor = compose.activity.window.decorView
            assertTrue("Activity must have a laid-out viewport", decor.width > 0 && decor.height > 0)
            Bitmap.createBitmap(decor.width, decor.height, Bitmap.Config.ARGB_8888).also {
                decor.draw(Canvas(it))
            }
        }
        assertTrue("Screenshot must have a non-empty viewport", bitmap.width > 0 && bitmap.height > 0)
        // A successful file write alone is not evidence of a rendered screen.
        val pixels = IntArray(bitmap.width * bitmap.height)
        bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
        assertTrue("Activity capture must contain drawn UI", pixels.any { it != pixels[0] })
        file.outputStream().use { output ->
            assertTrue("PNG encoder failed for $name", bitmap.compress(Bitmap.CompressFormat.PNG, 100, output))
        }
        assertTrue("PNG was not written: ${file.absolutePath}", file.length() > 0)
    }
}
