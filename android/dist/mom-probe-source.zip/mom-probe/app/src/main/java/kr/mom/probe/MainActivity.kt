package kr.mom.probe

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.provider.DocumentsContract
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kr.mom.probe.data.ProbeRecord
import kr.mom.probe.data.ProbeRepository
import kr.mom.probe.service.ProbeNotificationListener
import kr.mom.probe.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Production research builds protect raw notifications in recents/screenshots.
        if (!BuildConfig.DEBUG) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val session = ViewModelProvider(this)[ProbeSession::class.java]
        setContent { MomTheme { ProbeApp(session) } }
    }
}

@Composable
fun ProbeApp(session: ProbeSession) {
    val context = LocalContext.current
    val repository = remember { ProbeRepository.get(context) }
    val settings by repository.settings.collectAsStateWithLifecycle()
    val records by repository.records.collectAsStateWithLifecycle()
    val ready by repository.isReady.collectAsStateWithLifecycle()
    val storageError by repository.lastError.collectAsStateWithLifecycle()
    val connected by repository.listenerConnected.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var screen by rememberSaveable { mutableStateOf("welcome") }
    var started by rememberSaveable { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var policy by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var previous by rememberSaveable { mutableStateOf("home") }
    var editingSources by rememberSaveable { mutableStateOf(false) }
    var editingChild by rememberSaveable { mutableStateOf(false) }
    var refresh by remember { mutableIntStateOf(0) }
    var access by remember { mutableStateOf(false) }
    var accessCompletesSetup by rememberSaveable { mutableStateOf(true) }
    var pendingAccessReturn by rememberSaveable { mutableStateOf(false) }
    val installed = remember(refresh) { SourceCatalog.installed(context) }
    val snackbar = remember { SnackbarHostState() }

    fun command(operation: suspend () -> Boolean, after: () -> Unit = {}) {
        if (busy) return
        scope.launch {
            busy = true
            try { if (operation()) after() else message = repository.lastError.value ?: "설정을 확인하고 다시 시도해주세요." }
            catch (error: Exception) {
                if (error is CancellationException) throw error
                message = "작업을 마치지 못했어요. 다시 시도해주세요."
            } finally { busy = false }
        }
    }

    fun proceedSetup() {
        accessCompletesSetup = true
        editingSources = false
        editingChild = false
        screen = when {
            settings.selectedPackages.isEmpty() -> "sources"
            settings.childName.isBlank() -> "child"
            !access -> "access"
            else -> "home"
        }
        if (screen == "home") command({ repository.completeSetup() })
    }

    fun openAccess() {
        pendingAccessReturn = true
        val component = ComponentName(context, ProbeNotificationListener::class.java).flattenToString()
        val detail = Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, component)
        try { context.startActivity(detail) }
        catch (_: Exception) {
            try { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            catch (_: Exception) { message = "휴대폰 설정에서 알림 접근을 찾아 ‘나는 엄마다’를 허용해주세요." }
        }
    }

    fun sendTestNotification() {
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("local-test", "연결 확인용 알림", NotificationManager.IMPORTANCE_DEFAULT))
        if (!manager.areNotificationsEnabled() || manager.getNotificationChannel("local-test")?.importance == NotificationManager.IMPORTANCE_NONE) {
            message = "알림 받기가 꺼져 있어요. 휴대폰 앱 알림 설정에서 켜주세요."
            context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName))
            return
        }
        val pending = PendingIntent.getActivity(context, 1, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        manager.notify(404, Notification.Builder(context, "local-test").setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("나는 엄마다 · 테스트 알림").setContentText("알림 보내기가 준비됐어요. 학교·학원 수집 결과와는 별개예요.")
            .setContentIntent(pending).setVisibility(Notification.VISIBILITY_PRIVATE).setAutoCancel(true).build())
        message = "테스트 알림을 보냈어요. 알림창에서 확인해주세요."
    }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) sendTestNotification() else message = "알림 받기를 켜지 않아도 수집 내용을 앱 안에서 볼 수 있어요."
    }
    val saveFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri == null) { session.exportPayload = null; session.exportIds = emptySet() }
        else {
            val content = session.exportPayload
            val requestedIds = session.exportIds
            scope.launch {
                busy = true
                try {
                    val now = System.currentTimeMillis()
                    val current = repository.records.value.filter { now - it.receivedAt < 14L * 86_400_000 }.map { it.id }.toSet()
                    if (!repository.settings.value.consent || content == null || !current.containsAll(requestedIds)) {
                        withContext(Dispatchers.IO) { try { DocumentsContract.deleteDocument(context.contentResolver, uri) } catch (_: Exception) { /* Provider may not support cleanup. */ } }
                        message = if (content == null) "앱이 다시 시작되어 저장을 중단했어요. 자료를 다시 검토해주세요." else "자료가 삭제되거나 보관 기간이 끝났어요. 다시 검토해주세요."
                    } else {
                        withContext(Dispatchers.IO) {
                            val stream = context.contentResolver.openOutputStream(uri, "wt") ?: throw IOException("No output stream")
                            stream.bufferedWriter(Charsets.UTF_8).use { it.write(content) }
                        }
                        message = "검토한 자료를 선택한 위치에 저장했어요."
                    }
                } catch (error: Exception) {
                    if (error is CancellationException) throw error
                    withContext(Dispatchers.IO) { try { DocumentsContract.deleteDocument(context.contentResolver, uri) } catch (_: Exception) { /* Keep the original local records. */ } }
                    message = "파일을 저장하지 못했어요. 위치를 확인하고 다시 시도해주세요."
                } finally { session.exportPayload = null; session.exportIds = emptySet(); busy = false }
            }
        }
    }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                access = repository.hasNotificationAccess()
                refresh++
                scope.launch { repository.cleanupExpired() }
            }
        }
        lifecycle.addObserver(observer)
        access = repository.hasNotificationAccess()
        onDispose { lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(ready) {
        if (ready && !started) {
            screen = when {
                !settings.consent -> "welcome"
                settings.onboardingDone -> "home"
                settings.selectedPackages.isEmpty() -> "sources"
                settings.childName.isBlank() -> "child"
                else -> "access"
            }
            started = true
        }
        if (ready && screen == "export" && session.exportSnapshot.isEmpty()) {
            screen = "inbox"
            message = "앱이 다시 시작되어 자료 검토를 다시 열어주세요."
        }
    }
    LaunchedEffect(ready, refresh) {
        if (ready && settings.consent) {
            val existing = installed.map { it.packageName }.toSet()
            val retained = repository.settings.value.selectedPackages.intersect(existing)
            if (retained != repository.settings.value.selectedPackages && repository.saveSourceSelection(retained)) {
                message = "휴대폰에서 없어진 앱의 새 알림 수집을 껐어요. 저장한 알림은 남아 있어요."
            }
        }
    }
    LaunchedEffect(access, screen, pendingAccessReturn) {
        if (ready && screen == "access" && access && settings.childName.isNotBlank() && settings.selectedPackages.isNotEmpty()) {
            if (accessCompletesSetup) {
                if (repository.completeSetup()) screen = "home"
            } else if (pendingAccessReturn) screen = "settings"
            pendingAccessReturn = false
        }
    }
    LaunchedEffect(message) { message?.let { snackbar.showSnackbar(it); message = null } }

    fun back() {
        val leavingExport = screen == "export"
        screen = when(screen) {
            "sources" -> if (settings.onboardingDone) previous else "welcome"
            "child" -> if (settings.onboardingDone) previous else "sources"
            "access" -> if (settings.onboardingDone) previous else "child"
            "detail", "export" -> previous
            else -> "home"
        }
        if (leavingExport) session.clearExport()
    }
    BackHandler(screen !in setOf("home", "inbox", "settings", "welcome")) { if (!busy) back() }

    val rootTab = screen in setOf("home", "inbox", "settings")
    Scaffold(
        containerColor = Clay.Background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (rootTab) ProbeBottomBar(screen) { screen = it }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).imePadding()) {
            if (storageError != null) {
                Column(Modifier.fillMaxWidth().background(Clay.Peach).padding(14.dp)) {
                    Text(storageError!!, color = Clay.Error, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { deleteTarget = "ALL" }, enabled = !busy) { Text("전체 삭제 후 다시 시작") }
                }
            }
            if (!ready || !started) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else when (screen) {
                "welcome" -> WelcomeScreen(busy, { command({ repository.acceptConsent() }) { screen = "sources" } }, { policy = true })
                "sources" -> SourcesScreen(installed, settings.selectedPackages, busy, editingSources, { packages ->
                    command({ repository.saveSourceSelection(packages) }) {
                        if (editingSources) screen = "settings"
                        else {
                            accessCompletesSetup = true
                            screen = if (settings.childName.isBlank()) "child" else "access"
                        }
                    }
                }, ::back, { if (editingSources) back() else command({ repository.deferSetup() }) { screen = "home" } }, { refresh++ })
                "child" -> ChildScreen(settings.childName, busy, { name -> command({ repository.saveChild(name) }) {
                    if (editingChild) screen = "settings" else { accessCompletesSetup = true; screen = "access" }
                } }, ::back)
                "access" -> AccessScreen(settings.selectedPackages.map { SourceCatalog.label(it) }, busy, ::openAccess,
                    { command({ repository.deferSetup() }) { screen = "home" } }, ::back)
                "home" -> HomeScreen(settings, records, access, connected, ::proceedSetup, { screen = "inbox" }, {
                    selectedId = it.id; previous = "home"; screen = "detail"
                })
                "inbox" -> InboxScreen(records, { selectedId = it.id; previous = "inbox"; screen = "detail" }, {
                    session.exportSnapshot = records; previous = "inbox"; screen = "export"
                })
                "detail" -> {
                    val record = records.find { it.id == selectedId }
                    if (record == null) Page { BackHeading("받은 알림", ::back); EmptyCard("삭제되었거나 보관 기간이 끝났어요", "현재 남아 있는 알림을 확인해주세요.") }
                    else DetailScreen(record, ::back, { deleteTarget = record.id }, {
                        val intent = context.packageManager.getLaunchIntentForPackage(record.packageName)
                        if (intent == null) message = "원래 앱을 찾지 못했어요. 휴대폰에서 직접 확인해주세요."
                        else try { context.startActivity(intent) } catch (_: Exception) { message = "원래 앱을 열지 못했어요. 직접 확인해주세요." }
                    })
                }
                "settings" -> SettingsScreen(settings, access, connected, records.size, busy,
                    { previous = "settings"; editingSources = true; screen = "sources" }, { previous = "settings"; editingChild = true; screen = "child" },
                    { enabled -> if (enabled && (!access || settings.childName.isBlank() || settings.selectedPackages.isEmpty())) proceedSetup() else command({ repository.setCollectionEnabled(enabled) }) },
                    { previous = "settings"; accessCompletesSetup = false; pendingAccessReturn = false; openAccess() },
                    { notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS) },
                    { deleteTarget = "ALL" }, { policy = true })
                "export" -> ExportScreen(session.exportSnapshot, settings.childName, busy, ::back) { payload, format, ids ->
                    session.exportPayload = payload; session.exportIds = ids
                    saveFile.launch("mom-probe-reviewed-${System.currentTimeMillis()}.$format")
                }
            }
        }
    }
    if (policy) AlertDialog(onDismissRequest = { policy = false }, title = { Text("엄마가 정하는 데이터") },
        text = { PolicyContent() }, confirmButton = { TextButton(onClick = { policy = false }) { Text("확인했어요") } })
    if (deleteTarget != null) {
        val all = deleteTarget == "ALL"
        AlertDialog(onDismissRequest = { if (!busy) deleteTarget = null }, title = { Text(if (all) "참여를 종료하고 모두 지울까요?" else "이 알림을 삭제할까요?") },
            text = { Text(if (all) "아이 이름, 선택한 앱, 모아둔 알림, 동의와 암호화 키를 모두 삭제해요. 새 수집도 멈춰요. 되돌릴 수 없으며 외부에 저장한 파일은 따로 삭제해야 해요." else "이 휴대폰에서 해당 알림을 영구 삭제해요. 되돌릴 수 없어요.") },
            confirmButton = { TextButton(enabled = !busy, onClick = {
                val target = deleteTarget!!
                command({ if (all) repository.deleteAll() else repository.deleteRecord(target) }) {
                    deleteTarget = null; session.clearExport()
                    screen = if (all) "welcome" else previous
                    message = if (all) "이 기기의 자료를 모두 삭제했어요." else "알림을 삭제했어요."
                }
            }) { Text(if (busy) "삭제 중…" else "삭제", color = Clay.Error) } },
            dismissButton = { TextButton(onClick = { deleteTarget = null }, enabled = !busy) { Text("취소") } })
    }
}
