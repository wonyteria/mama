package kr.mom.probe.ui

import androidx.compose.foundation.background
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kr.mom.probe.data.ProbeRecord
import kr.mom.probe.data.ProbeSettings

fun displayTime(millis: Long): String = Instant.ofEpochMilli(millis).atZone(ZoneId.of("Asia/Seoul"))
    .format(DateTimeFormatter.ofPattern("M월 d일 HH:mm"))

@Composable
fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp).padding(top = 14.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp), content = content)
}

@Composable
fun BackHeading(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack, modifier = Modifier.sizeIn(minWidth = 48.dp, minHeight = 48.dp)) { Text("‹", fontSize = 30.sp) }
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun Brand() {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Eyebrow("첫 사용 테스트")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("나는 엄마다", style = MaterialTheme.typography.titleLarge)
            LeafMark()
        }
    }
}

@Composable
fun ConsentRow(checked: Boolean, onChange: (Boolean) -> Unit, text: String) {
    Row(Modifier.fillMaxWidth().toggleable(checked, role = Role.Checkbox, onValueChange = onChange).padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked, onCheckedChange = null)
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun WelcomeScreen(busy: Boolean, onStart: () -> Unit, onPolicy: () -> Unit) {
    var agreed by rememberSaveable { mutableStateOf(false) }
    Page {
        Brand()
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("엄마의 하루에,\n작은 여유를.", Modifier.weight(1f), style = MaterialTheme.typography.headlineLarge)
            if (LocalDensity.current.fontScale <= 1.25f) BellMascot(Modifier.size(106.dp, 130.dp))
        }
        Text("학교·학원 알림,\n같이 챙길 준비를 해요.", style = MaterialTheme.typography.titleLarge)
        ClayCard(tint = Clay.Sage) {
            StatusPill("가볍게 시작해요")
            Text("앱 고르기 → 아이 이름 → 허용", style = MaterialTheme.typography.titleMedium)
            Text("복잡한 가입 없이 이 휴대폰에서 시작해요.\n처음에는 자녀 1명, 앱 2개까지 연결해요.", color = Clay.Muted)
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("이번 버전은 알림이 잘 들어오는지 확인하는 테스트예요. AI 자동 챙김은 아직 제공하지 않아요.", style = MaterialTheme.typography.bodyMedium, color = Clay.Muted)
            Text("선택한 앱의 알림 내용과 아이 이름을 이 기기에 암호화해 보관해요. 알림은 14일 뒤 삭제되며 서버로 자동 전송하지 않아요. 재설치하면 기록을 복구할 수 없어요.", style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
            TextButton(onClick = onPolicy) { Text("수집·보관·삭제 설명 보기") }
            ConsentRow(agreed, { agreed = it }, "설명을 확인했고, 이 기기에서의 알림 수집 테스트에 동의해요. (필수)")
        }
        ClayButton(if (busy) "준비하고 있어요…" else "이 기기에서 시작", Modifier.testTag("start"), agreed && !busy, onClick = onStart)
    }
}

@Composable
fun SourcesScreen(apps: List<SourceApp>, initial: Set<String>, busy: Boolean, allowEmpty: Boolean = false, onSave: (Set<String>) -> Unit,
                  onBack: () -> Unit, onSkip: () -> Unit, onRefresh: () -> Unit) {
    var selected by remember(apps, initial) { mutableStateOf(initial.intersect(apps.map { it.packageName }.toSet())) }
    var showCatalog by rememberSaveable { mutableStateOf(false) }
    var discard by remember { mutableStateOf(false) }
    val initialInstalled = initial.intersect(apps.map { it.packageName }.toSet())
    fun requestBack() { if (selected != initialInstalled) discard = true else onBack() }
    BackHandler(selected != initialInstalled) { discard = true }
    Page {
        BackHeading("챙길 앱 고르기", ::requestBack)
        Eyebrow("1 / 3  ·  챙길 앱")
        Text("어떤 앱을\n챙겨드릴까요?", style = MaterialTheme.typography.headlineLarge)
        Text("휴대폰에서 찾은 테스트 대상 앱이에요.\n하나만 골라도 시작할 수 있어요.", color = Clay.Muted)
        if (apps.isEmpty()) {
            ClayCard(tint = Clay.Sage) {
                Text("아직 연결할 앱을 찾지 못했어요", style = MaterialTheme.typography.titleMedium)
                Text("학교·학원 앱이 이 휴대폰에 설치되어 있는지 확인해주세요. 설치되어도 목록에 없는 앱은 이번 테스트 대상이 아니에요.", color = Clay.Muted)
                ClayButton("설치한 앱 다시 확인", primary = false, onClick = onRefresh)
            }
        } else {
            apps.forEachIndexed { index, app ->
                val checked = app.packageName in selected
                val allowed = checked || selected.size < 2
                Row(Modifier.fillMaxWidth().claySurface(if (checked) Clay.Sage else Clay.Background)
                    .toggleable(checked, enabled = allowed, role = Role.Checkbox) {
                        selected = if (checked) selected - app.packageName else selected + app.packageName
                    }.padding(18.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(Modifier.size(48.dp).claySurface(if (index % 2 == 0) Clay.Peach else Clay.Lavender, 16.dp), contentAlignment = Alignment.Center) {
                        Text(app.mark, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Clay.Ink)
                    }
                    Column(Modifier.weight(1f)) { Text(app.name, fontWeight = FontWeight.Bold); Text(app.category, color = Clay.Muted, style = MaterialTheme.typography.bodySmall) }
                    Checkbox(checked, onCheckedChange = null, enabled = allowed)
                }
            }
            Text("${selected.size}/2개 선택 · 알림 수집 가능 여부는 테스트 중이에요.", style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
        }
        ClayButton(if (allowEmpty) "선택 저장" else "이 앱 챙기기", Modifier.testTag("save-sources"), (selected.isNotEmpty() || allowEmpty) && !busy, onClick = { onSave(selected) })
        if (allowEmpty) Text("선택을 해제하면 해당 앱의 새 알림 수집만 멈춰요. 모아둔 알림은 14일 보관 규칙에 따라 남아 있어요.", style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
        TextButton(onClick = onSkip, enabled = !busy, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("나중에 설정할게요") }
        TextButton(onClick = { showCatalog = !showCatalog }) { Text(if (showCatalog) "테스트 대상 접기" else "어떤 앱이 테스트 대상인가요?") }
        if (showCatalog) Text(SourceCatalog.candidates.joinToString(" · ") { it.name } + "\n앱 계정 연결이나 공지 원문 전체 접근을 보장하지 않아요.", color = Clay.Muted, style = MaterialTheme.typography.bodyMedium)
    }
    if (discard) DiscardDialog({ discard = false }, { discard = false; onBack() })
}

@Composable
fun ChildScreen(initial: String, busy: Boolean, onSave: (String) -> Unit, onBack: () -> Unit) {
    var name by rememberSaveable(initial) { mutableStateOf(initial) }
    var discard by remember { mutableStateOf(false) }
    fun requestBack() { if (name != initial) discard = true else onBack() }
    BackHandler(name != initial) { discard = true }
    val valid = name.trim().isNotEmpty() && name.trim().length <= 20 && name.none { it.isISOControl() }
    Page {
        BackHeading("아이 이름", ::requestBack)
        Eyebrow("2 / 3  ·  아이 이름")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("어떻게\n불러드릴까요?", Modifier.weight(1f), style = MaterialTheme.typography.headlineLarge)
            if (LocalDensity.current.fontScale <= 1.25f) BellMascot(Modifier.size(100.dp, 118.dp))
        }
        Text("이름이나 별칭 하나만 알려주세요.\n학교·학원 정보는 지금 입력하지 않아도 돼요.", color = Clay.Muted)
        OutlinedTextField(name, { if (it.length <= 40) name = it }, modifier = Modifier.fillMaxWidth().testTag("child-name"),
            label = { Text("아이 이름 또는 별칭") }, placeholder = { Text("예: 서윤, 우리 아이") },
            singleLine = true, shape = RoundedCornerShape(22.dp), isError = name.isNotEmpty() && !valid,
            supportingText = { Text(if (name.isNotEmpty() && !valid) "이름 또는 별칭을 1~20자로 입력해주세요." else "이 휴대폰 안에만 안전하게 저장해요.") })
        ClayButton(if (busy) "저장하고 있어요…" else "다음", Modifier.testTag("save-child"), valid && !busy, onClick = { onSave(name.trim()) })
    }
    if (discard) DiscardDialog({ discard = false }, { discard = false; onBack() })
}

@Composable
private fun DiscardDialog(onKeep: () -> Unit, onDiscard: () -> Unit) {
    AlertDialog(onDismissRequest = onKeep, title = { Text("입력한 내용을 남겨둘까요?") },
        text = { Text("아직 저장하지 않았어요. 돌아가면 지금 바꾼 내용은 저장되지 않아요.") },
        confirmButton = { TextButton(onClick = onKeep) { Text("계속 입력") } },
        dismissButton = { TextButton(onClick = onDiscard) { Text("저장하지 않고 돌아가기") } })
}

@Composable
fun AccessScreen(labels: List<String>, busy: Boolean, onOpen: () -> Unit, onSkip: () -> Unit, onBack: () -> Unit) {
    var help by rememberSaveable { mutableStateOf(false) }
    Page {
        BackHeading("마지막 설정", onBack)
        Eyebrow("3 / 3  ·  알림 읽기 허용")
        Text("이제 알림을\n읽도록 허용해요.", style = MaterialTheme.typography.headlineLarge)
        ClayCard(tint = Clay.Sage) {
            StatusPill("엄마가 고른 앱만")
            Text(labels.joinToString(" · "), style = MaterialTheme.typography.titleLarge)
            Text("이 앱에 새로 도착한 알림 내용을 확인할게요. 다른 앱의 내용은 저장하지 않아요.", color = Clay.Muted)
        }
        Text("Android는 넓은 알림 접근을 허용하는 화면을 보여줘요. 나는 엄마다는 위에서 고른 앱만 처리해요.", style = MaterialTheme.typography.bodyMedium, color = Clay.Muted)
        ClayButton("설정 열기", Modifier.testTag("open-access"), !busy, onClick = onOpen)
        Text("돌아오시면 설정됐는지 자동으로 확인할게요.", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
        TextButton(onClick = { help = !help }) { Text("어디를 누르나요?  ${if (help) "−" else "+"}") }
        if (help) ClayCard {
            Text("1. 설정에서 ‘나는 엄마다’를 찾아요.\n2. 알림 읽기를 허용해요.\n3. 뒤로가기로 앱에 돌아와요.", style = MaterialTheme.typography.bodyLarge)
            Text("휴대폰에 따라 설정 이름과 위치가 달라요. ‘제한된 설정’이 보이면 설치 경로에 따른 추가 안내가 필요할 수 있어요. 어려우면 나중에 이어서 해도 괜찮아요.", style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
        }
        TextButton(onClick = onSkip, enabled = !busy, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("나중에 설정할게요") }
    }
}

@Composable
fun HomeScreen(settings: ProbeSettings, records: List<ProbeRecord>, access: Boolean, connected: Boolean,
               onSetup: () -> Unit, onInbox: () -> Unit, onRecord: (ProbeRecord) -> Unit) {
    val configured = settings.selectedPackages.isNotEmpty() && settings.childName.isNotBlank() && access
    val active = configured && settings.collectionEnabled
    val title = when {
        !configured -> "함께 챙길\n준비를 해요"
        !active -> "잠시 쉬어가도\n괜찮아요"
        else -> "${settings.childName}의 소식,\n여기에 모아둘게요"
    }
    Page {
        Brand()
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), style = MaterialTheme.typography.headlineMedium)
            if (LocalDensity.current.fontScale <= 1.25f) BellMascot(Modifier.size(98.dp, 118.dp))
        }
        ClayCard(tint = Clay.Sage, modifier = Modifier.fillMaxWidth()) {
            StatusPill(when { !configured -> "설정 이어하기"; !active -> "잠시 멈춤"; !connected -> "연결 준비 중"; else -> "알림 수집 중" })
            Text(when { !configured -> "마지막 준비를 도와드릴게요"; !active -> "알림 모으기를 멈췄어요"; records.isEmpty() -> "새 알림을 기다리고 있어요"; else -> "새 소식을 모아두었어요" }, style = MaterialTheme.typography.titleLarge)
            Text(when {
                !configured -> "한 번만 설정하면, 고른 앱의 새 알림을\n이 휴대폰에서 확인할 수 있어요."
                !active -> "저장한 소식은 그대로 있어요.\n원할 때 다시 시작할 수 있어요."
                else -> "고른 앱에 새 알림이 오면\n여기에 차곡차곡 모아둘게요."
            }, color = Clay.Muted)
            if (!active) ClayButton(if (configured) "다시 시작하기" else "이어서 설정하기", Modifier.testTag("resume-setup"), primary = false, onClick = onSetup)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            StatCard(records.size.toString(), "받은 알림", Modifier.weight(1f), Clay.Background)
            StatCard(settings.selectedPackages.size.toString(), "챙길 앱", Modifier.weight(1f), Clay.Background)
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("최근 받은 알림", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = onInbox) { Text("전체 보기  ›", style = MaterialTheme.typography.bodySmall) }
        }
        if (records.isEmpty()) EmptyCard("아직 도착한 알림이 없어요", "새로 도착한 알림부터 확인해요.")
        else records.take(3).forEach { RecordCard(it, onClick = { onRecord(it) }) }
        Text("학교·학원 알림 수집을 확인하는 테스트예요.\nAI 자동 챙김은 준비 중이에요.", Modifier.fillMaxWidth(), style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center, color = Clay.Muted)
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier, tint: Color) {
    Row(modifier.claySurface(tint).padding(horizontal = 19.dp, vertical = 22.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
        Text(value, style = MaterialTheme.typography.headlineMedium)
        Text(label, color = Clay.Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun EmptyCard(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().border(1.dp, Color(0xFFD6DED3), RoundedCornerShape(28.dp)).padding(26.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NavGlyph("inbox", false, Modifier.size(32.dp))
        Text(title, style = MaterialTheme.typography.bodyMedium, color = Clay.Muted, textAlign = TextAlign.Center)
        if (subtitle.isNotEmpty()) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Clay.Muted, textAlign = TextAlign.Center)
    }
}

@Composable
fun RecordCard(record: ProbeRecord, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().claySurface().clickable(role = Role.Button, onClick = onClick).padding(20.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row { Text(record.appLabel, Modifier.weight(1f), color = Clay.Green, style = MaterialTheme.typography.bodySmall); Text(displayTime(record.receivedAt), color = Clay.Muted, style = MaterialTheme.typography.bodySmall) }
        Text(record.title.ifBlank { "제목 없는 알림" }, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        val body = record.bigText.ifBlank { record.text }.ifBlank { record.textLines.joinToString(" ") }
        Text(body.ifBlank { "알림에 내용이 없어요. 원래 앱에서 확인해주세요." }, color = Clay.Muted, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun InboxScreen(records: List<ProbeRecord>, onRecord: (ProbeRecord) -> Unit, onExport: () -> Unit) {
    var filter by rememberSaveable { mutableStateOf("") }
    var limit by remember { mutableIntStateOf(30) }
    val packages = records.map { it.packageName }.distinct()
    val shown = records.filter { filter.isEmpty() || it.packageName == filter }
    Page {
        Eyebrow("이 기기에 모아둔 소식")
        Text("받은 알림", style = MaterialTheme.typography.headlineLarge)
        Text("총 ${records.size}개 · 14일 동안 보관해요", color = Clay.Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterChip(filter.isEmpty(), { filter = ""; limit = 30 }, label = { Text("전체") })
            packages.take(2).forEach { pkg -> FilterChip(filter == pkg, { filter = pkg; limit = 30 }, label = { Text(SourceCatalog.label(pkg).take(8)) }) }
        }
        if (shown.isEmpty()) EmptyCard("아직 모아둔 알림이 없어요", "연결한 앱에 새 알림이 오면 여기에 보여요.")
        else shown.take(limit).forEach { RecordCard(it) { onRecord(it) } }
        if (shown.size > limit) TextButton(onClick = { limit += 30 }) { Text("더 보기") }
        ClayButton("연구자료 검토하고 저장", enabled = records.isNotEmpty(), primary = false, onClick = onExport)
    }
}

@Composable
fun DetailScreen(record: ProbeRecord, onBack: () -> Unit, onDelete: () -> Unit, onSource: () -> Unit) {
    var fields by rememberSaveable(record.id) { mutableStateOf(false) }
    Page {
        BackHeading("받은 알림", onBack)
        StatusPill(record.appLabel)
        Text(record.title.ifBlank { "제목 없는 알림" }, style = MaterialTheme.typography.headlineMedium)
        Text("${displayTime(record.receivedAt)} 받았어요", color = Clay.Muted, style = MaterialTheme.typography.bodySmall)
        if (record.truncated) Text("긴 알림의 일부만 저장됐어요. 전체 내용은 원래 앱에서 확인해주세요.", color = Clay.Error, style = MaterialTheme.typography.bodyMedium)
        ClayCard(tint = Clay.Sage) {
            val body = record.bigText.ifBlank { record.text }.ifBlank { record.textLines.joinToString("\n") }
            SelectionContainer { Text(body.ifBlank { "앱이 알림 내용을 보내주지 않았어요. 원래 앱에서 직접 확인해주세요." }, style = MaterialTheme.typography.bodyLarge) }
        }
        ClayButton("원래 앱에서 확인", primary = false, onClick = onSource)
        TextButton(onClick = { fields = !fields }) { Text(if (fields) "수집 내용 접기" else "수집한 내용 모두 보기") }
        if (fields) {
            listOf("제목" to record.title, "짧은 본문" to record.text, "펼친 본문" to record.bigText,
                "본문 줄" to record.textLines.joinToString("\n"), "추가 설명" to record.subText.orEmpty(), "묶음 설명" to record.summaryText.orEmpty(),
                "원래 게시 시각" to displayTime(record.postedAt)).forEach { (label, value) ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(label, color = Clay.Green, style = MaterialTheme.typography.labelLarge); SelectionContainer { Text(value.ifBlank { "내용 없음" }, color = Clay.Muted) } }
            }
        }
        Text("원문을 그대로 보여주는 수집 테스트예요.\n내용을 분석하거나 일정으로 등록하지 않아요.", style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
        TextButton(onClick = onDelete, colors = ButtonDefaults.textButtonColors(contentColor = Clay.Error)) { Text("이 알림 삭제") }
    }
}

@Composable
fun SettingsScreen(settings: ProbeSettings, access: Boolean, connected: Boolean, recordCount: Int, busy: Boolean,
                   onSources: () -> Unit, onChild: () -> Unit, onToggle: (Boolean) -> Unit,
                   onPermission: () -> Unit, onTest: () -> Unit, onDelete: () -> Unit, onPolicy: () -> Unit) {
    var details by rememberSaveable { mutableStateOf(false) }
    Page {
        Eyebrow("엄마가 정하는 범위")
        Text("설정", style = MaterialTheme.typography.headlineLarge)
        ClayCard(tint = Clay.Sage) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("알림 모으기", style = MaterialTheme.typography.titleMedium); Text(if (settings.collectionEnabled) "선택한 앱의 새 알림만 모아요" else "지금은 쉬고 있어요", style = MaterialTheme.typography.bodySmall, color = Clay.Muted) }
                Switch(settings.collectionEnabled, onCheckedChange = onToggle, enabled = !busy)
            }
            Text("끄면 새 알림 수집이 멈춰요.\n이미 모은 알림은 그대로 남아 있어요.", color = Clay.Muted, style = MaterialTheme.typography.bodySmall)
        }
        ClayCard {
            SettingLink("챙길 앱", "${settings.selectedPackages.size}개 선택", onSources)
            HorizontalDivider(color = Color.White)
            SettingLink("아이 이름", settings.childName.ifBlank { "아직 입력 전" }, onChild)
            HorizontalDivider(color = Color.White)
            SettingLink("알림 읽기", if (access) "허용됨" else "설정 필요", onPermission)
        }
        TextButton(onClick = { details = !details }) { Text(if (details) "연결 상태 접기" else "연결 상태 자세히 보기") }
        if (details) ClayCard {
            Text(if (!access) "알림 읽기가 꺼져 있어요" else if (connected) "알림을 받을 준비가 됐어요" else "휴대폰과 연결을 준비하고 있어요", style = MaterialTheme.typography.titleMedium)
            Text("저장된 알림 ${recordCount}개\n선택한 앱: ${settings.selectedPackages.joinToString(" · ") { SourceCatalog.label(it) }.ifBlank { "없음" }}", style = MaterialTheme.typography.bodyMedium, color = Clay.Muted)
            TextButton(onClick = onTest) { Text("테스트 알림 보내기") }
            Text("이 버튼은 앱의 알림 보내기만 확인해요. 학교 앱 수집 성공을 뜻하지 않아요.", style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
        }
        SettingLink("수집·보관·삭제 설명", "이 기기에서만 보관", onPolicy)
        Text("이번 테스트는 무료예요.\n원문은 14일 뒤 삭제하고, 자동으로 외부에 보내지 않아요.", style = MaterialTheme.typography.bodyMedium, color = Clay.Muted)
        TextButton(onClick = onDelete, enabled = !busy, colors = ButtonDefaults.textButtonColors(contentColor = Clay.Error)) { Text("참여 종료 · 전체 데이터 삭제") }
        Text("나는 엄마다 · 첫 사용 테스트 0.1.0", style = MaterialTheme.typography.bodySmall, color = Clay.Muted)
    }
}

@Composable
private fun SettingLink(title: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).clickable(role = Role.Button, onClick = onClick).padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, style = MaterialTheme.typography.titleMedium); Text(value, color = Clay.Muted, style = MaterialTheme.typography.bodySmall) }
        Text("›", fontSize = 24.sp, color = Clay.Muted)
    }
}

@Composable
fun PolicyContent() {
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Text("이번 버전은 학교·학원 앱의 알림 수집 가능성을 확인하는 MOM PROBE입니다.")
        Text("수집: 직접 선택한 앱의 새 알림 제목·본문·게시 시각·앱 정보, 입력한 아이 이름/별칭. 다른 앱 내용은 저장하지 않습니다.")
        Text("보관: Android 보안 키로 암호화하여 이 휴대폰에만 저장합니다. 원문은 받은 날부터 14일, 아이 이름과 설정은 참여 종료까지 보관합니다. 휴대폰이 꺼져 있으면 다음 실행 시 만료 자료를 정리합니다.")
        Text("외부 전송: 서버·AI·광고·사용성 분석 서비스로 자동 전송하지 않습니다. 연구자료는 내용을 검토하고 별도로 동의한 뒤 사용자가 파일로 저장할 때만 기기 밖 사본을 만들 수 있습니다.")
        Text("통제: 언제든 앱 선택을 바꾸거나 수집을 멈출 수 있습니다. 개별 알림 또는 전체 정보를 삭제할 수 있습니다. 전체 삭제는 동의와 암호화 키까지 제거합니다.")
        Text("제한: 앱 안의 공지·첨부파일 전체를 읽지 않습니다. 자동 챙김·AI 요약·결제는 없습니다. 앱 삭제/재설치/기기 변경 시 복구하지 않습니다. 이미 외부에 저장한 파일은 앱에서 회수할 수 없습니다.")
    }
}
