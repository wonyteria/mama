package kr.mom.probe.reminder

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import kr.mom.probe.MainActivity
import kr.mom.probe.R
import kr.mom.probe.data.NotificationCandidate
import kr.mom.probe.data.NotificationCandidateParser
import kr.mom.probe.data.ProbeRecord
import kr.mom.probe.data.ProbeRules

/** Posts a private, review-first alert for deterministic action candidates. */
object AssistantAlertNotifier {
    private const val CHANNEL = "mom-action-candidates"
    private const val PREFS = "assistant-alerts"
    private const val ENABLED = "enabled"

    fun isEnabled(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getBoolean(ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .edit().putBoolean(ENABLED, enabled).commit()

    fun reset(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit()

    fun notify(context: Context, record: ProbeRecord): Boolean {
        if (!isEnabled(context)) return false
        val candidate = NotificationCandidateParser.parse(record) ?: return false
        if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return false
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(
            CHANNEL,
            "모모의 챙길 일",
            NotificationManager.IMPORTANCE_HIGH,
        ).apply {
            description = "준비물·제출·마감으로 보이는 새 알림을 확인하도록 알려줘요"
            lockscreenVisibility = Notification.VISIBILITY_PRIVATE
            enableVibration(true)
        })
        if (!manager.areNotificationsEnabled() || manager.getNotificationChannel(CHANNEL)?.importance == NotificationManager.IMPORTANCE_NONE) return false

        val stableNotificationId = ProbeRules.notificationIdentity(record.packageName, record.notificationKey).hashCode()
        val open = PendingIntent.getActivity(
            context,
            stableNotificationId,
            Intent(context, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_RECORD_ID, record.id)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val description = when (candidate.kind) {
            NotificationCandidate.Kind.PREPARE -> "준비물이 필요해 보여요"
            NotificationCandidate.Kind.SUBMIT -> "제출하거나 신청할 일이 있어 보여요"
            NotificationCandidate.Kind.DEADLINE -> "마감이 있는 일로 보여요"
        }
        val privateNotification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("모모가 챙길 일을 찾았어요")
            .setContentText(listOfNotNull(record.title.ifBlank { description }, candidate.dueText).joinToString(" · "))
            .setStyle(NotificationCompat.BigTextStyle().bigText("$description. 눌러서 원문을 확인해주세요."))
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPublicVersion(NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("나는 엄마다")
                .setContentText("확인할 새 소식이 있어요")
                .build())
            .build()
        return try {
            manager.notify(stableNotificationId, privateNotification)
            true
        } catch (_: SecurityException) {
            false
        }
    }
}
