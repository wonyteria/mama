package kr.mom.probe.reminder

import android.content.Intent
import android.app.KeyguardManager
import android.app.NotificationManager
import android.view.WindowManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale
import kr.mom.probe.MainActivity
import kr.mom.probe.BuildConfig
import kr.mom.probe.task.AssistantTaskStore
import kr.mom.probe.task.AssistantTasksActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kr.mom.probe.data.ProbeRepository
import kr.mom.probe.data.ProbeRules
import kr.mom.probe.ui.MomTheme
import kr.mom.probe.ui.AgentButton
import kr.mom.probe.ui.AgentCard
import kr.mom.probe.ui.BellMascot
import kr.mom.probe.ui.Clay

class BriefingActivity : ComponentActivity() {
    private var speech: TextToSpeech? = null
    private var speechReady by mutableStateOf(false)
    private var unlocked by mutableStateOf(false)
    override fun onResume() {
        super.onResume()
        unlocked = !getSystemService(KeyguardManager::class.java).isKeyguardLocked
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!BuildConfig.DEBUG) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        if (intent.getBooleanExtra("ringing", false)) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        speech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) speechReady = (speech?.setLanguage(Locale.KOREAN) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= 0
        }
        setContent {
            MomTheme {
                val repository = remember { ProbeRepository.get(this) }
                val ready by repository.isReady.collectAsState()
                val settings by repository.settings.collectAsState()
                val records by repository.records.collectAsState()
                val error by repository.lastError.collectAsState()
                val taskStore = remember { AssistantTaskStore.get(this) }
                val tasks by taskStore.tasks.collectAsState()
                var taskError by remember { mutableStateOf(false) }
                var taskLoading by remember { mutableStateOf(true) }
                val demo = intent.getBooleanExtra(BriefingReminders.DEMO, false)
                val allowed = unlocked && ready && settings.consent && settings.consentVersion == ProbeRules.CONSENT_VERSION && settings.onboardingDone && error == null
                LaunchedEffect(allowed) {
                    if (allowed) {
                        taskLoading = true
                        try { withContext(Dispatchers.IO) { taskStore.load() }; taskError = false } catch (_: Exception) { taskError = true }
                        finally { taskLoading = false }
                    }
                }
                val pending = if (allowed && !taskError) tasks.filterNot { it.completed } else emptyList()
                val count = if (allowed) remember(records) { BriefingReminders.unseenCount(this, repository) } else 0
                val text = when {
                    !unlocked -> "모모가 알려드릴 소식이 있어요. 잠금을 풀고 확인해 주세요."
                    !allowed -> "첫 설정을 마친 뒤 다시 불러주세요."
                    demo -> "비서 알림 미리보기예요. 앞으로 정한 시간에 새로 모인 알림을 알려드릴게요."
                    taskLoading -> "부탁을 확인하고 있어요."
                    taskError -> "부탁을 불러오지 못했어요. 새 알림은 ${count}개예요."
                    count == 0 && pending.isEmpty() -> "새 알림과 남은 부탁이 없어요. 연결된 모든 앱과 사이트를 확인했다는 뜻은 아니에요."
                    else -> "부탁 ${pending.size}개, 새 알림 ${count}개가 있어요. " + pending.take(3).joinToString(". ") { it.text }
                }
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.safeDrawingPadding().padding(24.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(20.dp)) {
                        TextButton(onClick = { finish() }) { Text("닫기") }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(if (demo) "비서 미리보기" else "모모의 브리핑", style = MaterialTheme.typography.headlineMedium)
                                Text("엄마가 정한 시간에 찾아왔어요", color = Clay.Muted, style = MaterialTheme.typography.bodySmall)
                            }
                            BellMascot(Modifier.size(width = 64.dp, height = 78.dp))
                        }
                        AgentCard(Modifier.fillMaxWidth()) {
                            Text(if (unlocked) "제가 지금 챙길게요" else "확인할 소식이 있어요", color = Clay.CoralDark, style = MaterialTheme.typography.bodyMedium)
                            Text(text, style = MaterialTheme.typography.titleLarge)
                        }
                        if (!unlocked) Button(onClick = {
                            getSystemService(KeyguardManager::class.java).requestDismissKeyguard(this@BriefingActivity, object : KeyguardManager.KeyguardDismissCallback() {
                                override fun onDismissSucceeded() { unlocked = true }
                            })
                        }, modifier = Modifier.fillMaxWidth()) { Text("잠금 풀고 확인") }
                        AgentButton("소리로 듣기", enabled = allowed && speechReady && (!taskLoading || demo)) {
                            stopAlarm(); speech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "briefing")
                        }
                        if (!speechReady) Text("한국어 음성 엔진이 준비되지 않았어요. 화면으로 확인할 수 있어요.", style = MaterialTheme.typography.bodySmall)
                        if (allowed && !demo) {
                            if (taskError) Text("부탁을 불러오지 못했어요. 앱에서 다시 확인해 주세요.")
                            OutlinedButton(onClick = { startActivity(Intent(this@BriefingActivity, AssistantTasksActivity::class.java)); finish() }, modifier = Modifier.fillMaxWidth()) { Text("부탁 확인하기") }
                            OutlinedButton(onClick = { startActivity(Intent(this@BriefingActivity, MainActivity::class.java)); finish() }, modifier = Modifier.fillMaxWidth()) { Text("앱에서 알림 확인") }
                            Text("조금 뒤 다시 알려드릴까요?", style = MaterialTheme.typography.titleMedium)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(10, 30, 60).forEach { minutes ->
                                    OutlinedButton(onClick = {
                                        BriefingReminders.snooze(this@BriefingActivity, intent.getIntExtra("slot", 0), minutes)
                                        finish()
                                    }, modifier = Modifier.weight(1f)) { Text("${minutes}분") }
                                }
                            }
                            TextButton(onClick = {
                                // Acknowledgement is separate from task completion and does not delete records.
                                BriefingReminders.markSeen(this@BriefingActivity, records.maxOfOrNull { it.receivedAt } ?: 0L); finish()
                            }) { Text("이 브리핑 확인했어요") }
                            Text("브리핑 확인은 준비 완료나 기록 삭제가 아니에요.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
    private fun stopAlarm() { getSystemService(NotificationManager::class.java).cancel(710 + intent.getIntExtra("slot", 0)) }
    override fun onStop() { stopAlarm(); speech?.stop(); super.onStop() }
    override fun onDestroy() { speech?.shutdown(); speech = null; super.onDestroy() }
}
