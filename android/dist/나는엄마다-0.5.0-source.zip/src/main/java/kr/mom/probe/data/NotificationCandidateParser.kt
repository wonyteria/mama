package kr.mom.probe.data

data class NotificationCandidate(
    val kind: Kind,
    val items: List<String>,
    val dueText: String?,
    val confidence: String = "확인 필요",
) {
    enum class Kind { PREPARE, SUBMIT, DEADLINE }
}

/** Small deterministic hint parser. It never creates an Action or schedules an alarm. */
object NotificationCandidateParser {
    private val relativeDeadline = Regex("(오늘|내일|모레|이번 주|다음 주)(?:\\s*(오전|오후)?\\s*(\\d{1,2})(?::(\\d{2}))?시?)?")
    private val calendarDeadline = Regex("(?:\\d{4}[./-]\\s*)?(\\d{1,2})[월./-]\\s*(\\d{1,2})일?(?:\\s*\\([월화수목금토일]\\))?(?:\\s*(오전|오후)?\\s*(\\d{1,2})(?::(\\d{2}))?시?)?")
    private val dayOnlyDeadline = Regex("\\d{1,2}일\\s*\\([월화수목금토일]\\)(?:\\s*(오전|오후)?\\s*\\d{1,2}(?::\\d{2})?시?)?")
    private val trigger = Regex("준비물|준비해야|준비해|챙겨|가져오|제출|신청|회신|마감|기한|납부|입금")
    private val negated = Regex("(준비|제출|신청|회신|납부|입금)\\s*(?:하지\\s*않아도|할\\s*필요가?\\s*없|없습니다|완료(?:했|되었|됐))|준비물\\s*(?:은|는|:)?\\s*(?:없음|없습니다|필요\\s*없)")
    private val providedBySchool = Regex("(?:학교|기관).{0,18}(?:지원|제공).{0,18}준비물|준비물.{0,18}(?:학교|기관).{0,18}(?:지원|제공)")
    private val explicitAction = Regex("준비해야|준비해|챙겨|가져오|제출|신청|회신|마감|기한|납부|입금")

    fun parse(record: ProbeRecord): NotificationCandidate? {
        val source = listOf(record.title, record.bigText, record.text, record.textLines.joinToString(" "))
            .filter { it.isNotBlank() }.joinToString(" ").replace(Regex("\\s+"), " ").trim()
        if (source.isBlank() || !trigger.containsMatchIn(source) || negated.containsMatchIn(source)) return null
        if (providedBySchool.containsMatchIn(source) && !explicitAction.containsMatchIn(source)) return null
        val due = relativeDeadline.find(source)?.value
            ?: calendarDeadline.find(source)?.value
            ?: dayOnlyDeadline.find(source)?.value
        val kind = when {
            source.contains("제출") || source.contains("신청") || source.contains("회신") || source.contains("납부") || source.contains("입금") -> NotificationCandidate.Kind.SUBMIT
            source.contains("마감") || source.contains("기한") -> NotificationCandidate.Kind.DEADLINE
            else -> NotificationCandidate.Kind.PREPARE
        }
        val items = extractItems(source)
        return NotificationCandidate(kind, items, due)
    }

    private fun extractItems(source: String): List<String> {
        val marker = listOf("준비물", "챙길 것", "준비해야 할 것").firstOrNull { source.contains(it) } ?: return emptyList()
        val tail = source.substringAfterLast(marker).substringBefore(".").substringBefore("\n").trim()
            .removePrefix(":").trim().removePrefix("은 ").removePrefix("는 ").removePrefix("이 ").removePrefix("가 ").trim()
        if (tail.isBlank()) return emptyList()
        return tail.split(',', '·', '/', '•').map { it.trim(' ', ':', '-', '–') }
            .filter { it.length in 1..40 }.take(8)
    }
}
