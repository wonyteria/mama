package kr.mom.probe.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class NotificationCandidateParserTest {
    private fun record(title: String, text: String) = ProbeRecord(
        id = "id", packageName = "pkg", appLabel = "학교", postedAt = 1, receivedAt = 1,
        title = title, text = text, bigText = "", textLines = emptyList(), subText = null,
        summaryText = null, category = null, channelId = null, notificationId = 1,
        notificationKey = "key", isOngoing = false, isGroupSummary = false, rawHash = "hash",
    )

    @Test fun findsPrepareItemsAndDueHint() {
        val candidate = NotificationCandidateParser.parse(record("체험학습 준비물", "준비물: 도시락, 물통, 모자. 내일 오전 9시까지"))
        assertNotNull(candidate)
        assertEquals(listOf("도시락", "물통", "모자"), candidate!!.items)
        assertEquals("내일 오전 9시", candidate.dueText)
    }

    @Test fun doesNotInventCandidateForInformationalText() {
        assertNull(NotificationCandidateParser.parse(record("학교 안내", "다음 주 체험학습이 진행됩니다.")))
    }

    @Test fun findsCalendarDateAndReplyAction() {
        val candidate = NotificationCandidateParser.parse(record("가정통신문", "9월 16일(화)까지 회신해 주세요."))
        assertNotNull(candidate)
        assertEquals(NotificationCandidate.Kind.SUBMIT, candidate!!.kind)
        assertEquals("9월 16일(화)", candidate.dueText)
    }

    @Test fun ignoresExplicitlyCompletedOrUnneededAction() {
        assertNull(NotificationCandidateParser.parse(record("제출 안내", "동의서는 제출하지 않아도 됩니다.")))
        assertNull(NotificationCandidateParser.parse(record("납부 안내", "참가비 납부 완료했습니다.")))
        assertNull(NotificationCandidateParser.parse(record("준비물 안내", "이번 활동은 준비물 없음입니다.")))
        assertNull(NotificationCandidateParser.parse(record("학습준비물", "학습준비물은 학교에서 지원합니다.")))
    }

    @Test fun stripsKoreanTopicParticleFromItems() {
        val candidate = NotificationCandidateParser.parse(record("체험 안내", "준비물은 도시락, 물통."))
        assertEquals(listOf("도시락", "물통"), candidate!!.items)
    }
}
