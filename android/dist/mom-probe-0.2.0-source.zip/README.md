# 나는 엄마다 · MOM PROBE 0.2

클레이모피즘을 적용한 Android 설치형 **알림·연결 검증 앱**입니다. 알림 수집, 나이스 공개 학교정보, e알리미·하이클래스 공식 로그인 세션 프로토타입을 포함합니다. AI 요약·개인 성적/출결 연동·구매 비교·결제는 아직 구현하지 않습니다.

## 구현된 동작

- 연구 목적·기기 내 보관·삭제 설명과 명시 동의.
- 자녀 이름/별칭·학교 이름·학년 등록. 학교 검색 결과가 하나면 나이스 공식 이름으로 정규화.
- 앱과 사이트를 한 목록에서 관리. 나이스 학교정보 공식 OpenAPI 연결과 향후30일 학사일정 표시.
- 설치된 학교종이/e알리미/하이클래스/키즈노트/클래스노트 중 최대 2개 선택. 패키지 이름은 확인했지만, 각 앱의 실제 알림 본문 제공 여부는 아직 실측하지 않았습니다.
- 앱 스위치를 처음 켤 때만 알림 접근 이유 팝업 표시, OS 설정 왕복 자동 확인, 원 앱 로그인 안내와 실행.
- 사이트 스위치에서 허용 HTTPS 도메인의 공식 로그인 화면을 열고 WebView 쿠키 세션 유지. 로그인 세션 준비와 실제 정보 읽기 성공을 분리 표시.
- 허용한 앱의 **새 알림만** 수집. 전체 알림, SMS, 연락처, 위치, 마이크, 접근성 권한을 사용하지 않습니다.
- Room DB의 원문과 설정을 Android Keystore AES-GCM으로 암호화. 14일 TTL, 앱/동의/권한 필터, 정확한 callback revision 중복 억제.
- 홈·받은 알림·상세·설정, 수집 일시정지, 앱 선택 변경, 개별/전체 삭제.
- 연구자료의 로컬 자동 가림, 추가로 가릴 문구·행 제외·기간/앱 필터, 명시 동의 후 JSON/CSV 파일 저장.
- 크림·세이지·살구색 클레이 카드, 큰 버튼, 스크롤 가능한 한국어 화면. 폰의 글꼴 확대 지원.

앱은 나이스 공식 OpenAPI와 사용자가 켠 사이트의 공식 로그인 화면을 위해 `INTERNET` 권한을 사용합니다. 입력한 학교명은 공식 학교 검색 요청에만 사용합니다. 계정 비밀번호를 앱 데이터로 저장하지 않고 사이트 쿠키 세션만 WebView 저장소에 유지합니다. 알림 원문은 서버·AI·분석 SDK로 자동 전송하지 않습니다. 파일 저장은 사용자가 선택한 문서 제공자가 처리하며, 외부 사본은 앱 전체 삭제로 회수할 수 없습니다.

## 빌드

Windows PowerShell에서:

```powershell
cd D:\Codex\mom-agent\android
.\scripts\bootstrap.ps1
.\scripts\build.ps1
```

도구는 `D:\Codex\.toolchains\mom-android`에 설치하며 프로세스에 필요한 환경변수만 설정합니다. Java17, Gradle8.13, AGP8.11.1, compile/target36, min33입니다. Compose·Room 등 앱 빌드에 필요한 공식 라이브러리를 사용하며, 첫 실행에는 다운로드가 필요합니다.

기본 검증은 APK 빌드·로컬 단위/UI 렌더링 테스트·Android Lint입니다. 빌드 결과는 `app/build/outputs/apk/debug/app-debug.apk`에 생깁니다. debug 키로 서명한 개발용 파일이며 Play 정식 배포/서명 설정과 별개입니다.

## 화면과 테스트

- `design/reference.png`: 클레이모피즘 디자인 참고. 실제 앱 스크린샷으로 표시하지 않습니다.
- `app/build/reports/screenshots/`: 실제 Compose 화면을 Robolectric Android34 native graphics로 렌더링하는 테스트 출력. 휴대폰이나 에뮬레이터의 실측 화면은 아닙니다.
- `app/build/reports/tests/testDebugUnitTest/index.html`: 최신 테스트 결과.
- `app/build/reports/lint-results-debug.html`: 정적 분석 결과.
- `VERIFICATION.md`: 수행한 검증과 미검증 범위를 기록합니다.

테스트용 `fixture`는 별도 앱이며 소비자 APK에 포함되지 않습니다. 합성 알림을 보내 실제 NotificationListener를 점검하기 위한 도구입니다. debug 빌드에서 이 도우미가 설치됐을 때만 테스트 대상 목록에 나타납니다. 정식 학교 앱을 가장하거나 실제 공지인 것처럼 표시하지 않습니다.

## 휴대폰에서 처음 사용하기

1. Android 13~16 개인 프로필 휴대폰에 테스트 APK를 전달하여 설치합니다.
2. 연구 설명에 동의하고 아이 이름/별칭·학교·학년을 입력합니다.
3. 연결 화면에서 앱 스위치를 켭니다. 처음 한 번 이유 팝업을 본 뒤 OS의 알림 읽기 접근을 허용하고, 돌아오면 원 앱 로그인을 확인합니다.
4. 사이트 스위치를 켰다면 앱 안의 공식 화면에서 직접 로그인합니다. 사이트가 허용하는 동안 세션을 유지하며 만료 시 다시 로그인이 필요합니다.
5. **그 이후** 선택한 학교/학원 앱에서 도착한 새 알림만 목록에 들어옵니다.
6. 원래 앱에 새 알림이 왔는데 목록에 없다면 읽기 권한·선택 앱·알림 모으기 상태를 확인합니다. 알림 본문이 부족하면 서비스별 허용된 원문 커넥터가 필요합니다.

APK 직접 설치 경로에 따라 Android의 ‘제한된 설정’ 안내가 나올 수 있습니다. 표준 설정에서 사용자가 허용해야 하며 앱이 우회/자동 허용하지 않습니다. 이후 일반 참가자 배포는 Google Play 내부 테스트를 준비하는 편이 설치 부담을 줄일 수 있지만, 현재 Play 등록이나 배포는 하지 않았습니다.

## 삭제와 복구

설정의 ‘참여 종료 · 전체 데이터 삭제’는 기록·아이 이름·앱 선택·동의·암호화 키를 지웁니다. 네트워크 승인을 기다리지 않습니다. 키를 지운 데이터는 복구할 수 없고 앱 백업/기기 이전도 제외합니다. 앱의 일반 데이터 화면은 release 빌드에서 화면 캡처/최근 앱 미리보기를 보호합니다. debug 빌드는 UI 검증을 위해 캡처를 허용하므로 연구자료 화면을 임의 공유하지 마세요.

## 남아 있는 검증

G0는 실제 엄마 5~10명, 7~14일, 중요 공지와 대조한 알림 300건 이상을 모아야 끝납니다. 정상 빌드나 합성 알림 테스트만으로 학교 앱 연동/사업 가능성을 입증하지 않습니다. G0 이후 별도 AI 평가를 통과해야 V0 자동 챙김을 개발합니다.

참고: [NotificationListenerService](https://developer.android.com/reference/android/service/notification/NotificationListenerService), [Android 알림 권한](https://developer.android.com/develop/ui/compose/notifications/notification-permission), [Room](https://developer.android.com/jetpack/androidx/releases/room), [Robolectric](https://robolectric.org/getting-started/).
