package kr.mom.probe.connector

import android.webkit.CookieManager
import android.webkit.WebStorage

object WebsiteSessionManager {
    fun clear(definition: SiteDefinition) {
        val cookieManager = CookieManager.getInstance()
        definition.allowedHostSuffixes.forEach { suffix ->
            listOf("https://$suffix/", "https://www.$suffix/").forEach { origin ->
                cookieManager.getCookie(origin).orEmpty().split(';')
                    .mapNotNull { it.substringBefore('=').trim().takeIf(String::isNotEmpty) }
                    .distinct().forEach { name ->
                        cookieManager.setCookie(origin, "$name=; Max-Age=0; Path=/; Secure; SameSite=Lax")
                    }
                WebStorage.getInstance().deleteOrigin(origin.trimEnd('/'))
            }
        }
        cookieManager.flush()
    }
}
