package kr.mom.probe.task

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AssistantTaskStoreTest {
    @Test fun consumingReminderClearsItAndReturnsOriginalTaskOnce() {
        val reminder = AssistantTask("one", "물통 챙기기", false, 10L, remindAt = 20L)
        val other = AssistantTask("two", "회신하기", false, 11L, remindAt = 30L)

        val (afterFirst, fired) = AssistantTaskStore.consumeReminderFrom(listOf(reminder, other), "one")
        val (afterSecond, firedAgain) = AssistantTaskStore.consumeReminderFrom(afterFirst, "one")

        assertEquals(reminder, fired)
        assertNull(afterFirst.first { it.id == "one" }.remindAt)
        assertEquals(30L, afterFirst.first { it.id == "two" }.remindAt)
        assertNull(firedAgain)
        assertEquals(afterFirst, afterSecond)
    }

    @Test fun completedTaskReminderCannotBeConsumed() {
        val completed = AssistantTask("done", "준비 완료", true, 10L, remindAt = 20L)
        val (unchanged, fired) = AssistantTaskStore.consumeReminderFrom(listOf(completed), "done")
        assertEquals(listOf(completed), unchanged)
        assertNull(fired)
    }

    @Test fun automaticNoticeRevisionSuspendsPreviousAutomaticTaskOnly() {
        val old = AssistantTask("old", "금요일 제출", false, 10L, sourceNotificationId = "source", sourceRevisionId = "rev1", sourceKind = AssistantTaskSource.AUTO_NOTICE, dueAt = 100L, remindAt = 90L)
        val user = AssistantTask("user", "직접 확인한 제출", false, 11L, sourceNotificationId = "manual", sourceRevisionId = "rev1", sourceKind = AssistantTaskSource.USER_CONFIRMED_NOTICE)

        val reconciled = AssistantTaskStore.reconcileAutomaticRevisionForTest(
            listOf(old, user),
            sourceNotificationId = "source",
            sourceRevisionId = "rev2",
        )
        val suspended = reconciled.first { it.id == "old" }

        assertFalse(suspended.completed)
        assertTrue(suspended.suspended)
        assertEquals("rev2", suspended.sourceRevisionId)
        assertNull(suspended.remindAt)
        assertFalse(reconciled.first { it.id == "user" }.completed)
    }

    @Test fun suspendedAutomaticTaskDoesNotLookCompletedToNotifierProjection() {
        val suspended = AssistantTask(
            "old",
            "정정 전 제출",
            false,
            10L,
            sourceNotificationId = "source",
            sourceRevisionId = "rev2",
            sourceKind = AssistantTaskSource.AUTO_NOTICE,
            suspended = true,
        )

        val completedSource = listOf(suspended).any { it.sourceNotificationId == "source" && it.completed }

        assertFalse(completedSource)
    }

    @Test fun staleOccurrenceCannotSnoozeOrCompleteLatestAlarm() {
        val active = AssistantTask(
            "task",
            "물티슈 넣기",
            false,
            10L,
            activeAlarmOccurrenceId = "new",
            activeAlarmScheduledAt = 1_000L,
            activeAlarmNotificationId = 27_100,
        )

        val (afterSnooze, snooze) = AssistantTaskStore.snoozeAlarmOccurrenceFrom(
            listOf(active),
            id = "task",
            occurrenceId = "old",
            nextAt = 2_000L,
            minutes = 10,
            nextOccurrenceId = "next",
        )
        val (afterComplete, completed) = AssistantTaskStore.completeAlarmOccurrenceFrom(afterSnooze, "task", "old")

        assertEquals(TaskAlarmSnoozeResult.Stale, snooze)
        assertFalse(completed)
        assertEquals(listOf(active), afterComplete)
    }

    @Test fun snoozePersistsNewOccurrenceAndKeepsAutoRetryCounterSeparate() {
        val active = AssistantTask(
            "task",
            "물통 챙기기",
            false,
            10L,
            reminderAttempts = 2,
            activeAlarmOccurrenceId = "fire",
            activeAlarmScheduledAt = 1_000L,
            activeAlarmNotificationId = 27_100,
        )

        val (next, result) = AssistantTaskStore.snoozeAlarmOccurrenceFrom(
            listOf(active),
            id = "task",
            occurrenceId = "fire",
            nextAt = 20_000L,
            minutes = 10,
            nextOccurrenceId = "next",
        )
        val snoozed = next.single()

        assertTrue(result is TaskAlarmSnoozeResult.Scheduled)
        assertEquals(20_000L, snoozed.remindAt)
        assertEquals("next", snoozed.reminderOccurrenceId)
        assertNull(snoozed.activeAlarmOccurrenceId)
        assertEquals(0, snoozed.reminderAttempts)
        assertEquals(1, snoozed.snoozeCount)
        assertEquals(10, snoozed.snoozeMinutes)
    }

    @Test fun snoozeStopsAtPerOccurrenceLimits() {
        val countLimit = AssistantTask(
            "count",
            "세 번 미룸",
            false,
            10L,
            activeAlarmOccurrenceId = "fire",
            snoozeCount = 3,
            snoozeMinutes = 30,
        )
        val minuteLimit = AssistantTask(
            "minutes",
            "한 시간 미룸",
            false,
            10L,
            activeAlarmOccurrenceId = "fire",
            snoozeCount = 2,
            snoozeMinutes = 40,
        )

        val (_, byCount) = AssistantTaskStore.snoozeAlarmOccurrenceFrom(listOf(countLimit), "count", "fire", 20_000L, 10, "next")
        val (_, byMinutes) = AssistantTaskStore.snoozeAlarmOccurrenceFrom(listOf(minuteLimit), "minutes", "fire", 20_000L, 30, "next")

        assertEquals(TaskAlarmSnoozeResult.LimitReached, byCount)
        assertEquals(TaskAlarmSnoozeResult.LimitReached, byMinutes)
    }

    @Test fun completingActiveOccurrenceFinishesOnlyThatTask() {
        val active = AssistantTask("one", "등교 가방", false, 10L, activeAlarmOccurrenceId = "fire", remindAt = 30L)
        val other = AssistantTask("two", "회신", false, 11L, activeAlarmOccurrenceId = "other", remindAt = 40L)

        val (next, completed) = AssistantTaskStore.completeAlarmOccurrenceFrom(listOf(active, other), "one", "fire")

        assertTrue(completed)
        assertTrue(next.first { it.id == "one" }.completed)
        assertNull(next.first { it.id == "one" }.remindAt)
        assertFalse(next.first { it.id == "two" }.completed)
        assertEquals(40L, next.first { it.id == "two" }.remindAt)
    }
}
